> **Catatan 15 Oktober 2026:** berkas APK yang dijelaskan di bawah sudah digantikan oleh build yang lebih baru
> (`English-Quest-1.7.1-register-test-localtest-debug.apk`) setelah perbaikan pendaftaran akun. Rincian terbaru
> ada di `english-quest/LAPORAN-PENDAFTARAN.md`. Dokumen ini tetap disimpan sebagai catatan verifikasi build sebelumnya.

# Verifikasi APK Debug — English Quest 1.7.1 (Demo 5 soal + halaman Premium)

Dibuat dari cabang `audit-baseline-1.7.1`, commit **`31a8c59`** (tree bersih). `main` tidak disentuh,
tidak ada push, tidak ada deployment, dan APK di dalam repositori **tidak** diganti.

## 1. Berkas artefak

| Item | Nilai |
|---|---|
| Berkas | `/home/user/artefak-apk/English-Quest-1.7.1-demo5-premium-debug.apk` |
| Salinan build | `/home/user/english-quest/english-quest-android/app/build/outputs/apk/debug/app-debug.apk` (tidak persisten antar sesi) |
| Ukuran | **84.925.244 byte** (80,99 MiB) |
| SHA-256 | `f3605181d063c18139b77da0e6ea676d2ba1079acc05bca098d3c3653667f1f0` |
| Berkas hash | `English-Quest-1.7.1-demo5-premium-debug.apk.sha256` |
| applicationId | `com.englishquest.app.debug` |
| versionName | `1.7.1-debug` (tidak diubah) |
| versionCode | `13` (tidak diubah) |
| minSdk / targetSdk | 23 / 35 (Android 6.0+) |
| Activity utama | `com.englishquest.app.MainActivity` |
| Sertifikat | `CN=Android Debug` (SHA-256 `7659afc5…50a3`) — debug, **bukan** untuk rilis |
| Skema tanda tangan | v1 ✓, v2 ✓ (v3/v4 tidak) |
| ABI native | arm64-v8a, armeabi-v7a, x86, x86_64 (+ entri warisan armeabi/mips dari library Vosk) |
| Izin | `android.permission.INTERNET`, `android.permission.RECORD_AUDIO` |
| Label | English Quest |

## 2. Hasil pemeriksaan terhadap 10 persyaratan

| # | Persyaratan | Hasil |
|---|---|---|
| 1 | APK debug terbaru tersedia | **OK** — build ulang dari HEAD `31a8c59` (`BUILD SUCCESSFUL`, 35 task) |
| 2 | APK memuat source terbaru, bukan APK lama | **OK** — 17/17 berkas web di dalam APK identik byte-for-byte dengan repo; APK repo lama (`05e06641…`) **tidak** memuat UI pembayaran dan masih berisi teks "10 soal", jadi jelas berbeda |
| 3 | Batas demo 5 soal Easy masuk ke APK | **OK** — satu misi Easy (`easy-greetings`), limit bawaan 5, clamp 1–5, ledger lokal hanya `easy-greetings-q1..q5`, label "DEMO GRATIS · 5 SOAL UNIK", tanpa sisa teks "10 soal"/"Dua misi" |
| 4 | Halaman Premium: Rp5.000 + sekali bayar permanen | **OK** — label `Rp5.000`, tombol "Bayar Rp5.000 (DANA)", teks "sekali bayar, akses permanen" dan "tanpa langganan atau tagihan berulang", harga mengikuti server, alur buat pesanan → periksa status → terima token |
| 5 | Simulator lokal tidak mengaktifkan pembayaran produksi | **OK** — lihat bagian 3 di bawah |
| 6 | Tanpa kredensial/rahasia produksi di APK | **OK** — tidak ada pola `client_secret`, `PRIVATE KEY`, `api_key`, `server_key`, `Bearer eyJ`, `EQ_TOKEN_PEPPER`, dll. di seluruh isi APK; satu-satunya kemiripan (`password=`) ternyata potongan kode `#access-password`, bukan rahasia |
| 7 | Tidak mengklaim DANA sudah berfungsi | **OK** — belum ada checkout/verifikasi transaksi nyata; status dinyatakan apa adanya di bagian 5 |
| 8 | APK siap diuji di HP Android | **OK** — terpasang lewat panduan bagian 4 |
| 9 | Path artefak + cara mengambil | **OK** — lihat bagian 1 dan 4 |
| 10 | Tidak ganti APK repo, tidak ubah versi, tidak push, tidak deploy | **OK** — APK repo utuh, versi tetap 13/`1.7.1-debug`, tanpa push dan tanpa deployment |

## 3. Mengapa pembayaran produksi tidak bisa aktif dari APK ini

1. **`EQ_API_BASE_URL` kosong di BuildConfig** (`public static final String EQ_API_BASE_URL = ""`). Tanpa origin server, `AccessApi.isConfigured()` bernilai false, sehingga halaman Premium menampilkan "Hubungkan akun email" dan **tombol bayar tidak pernah muncul** (diuji otomatis di kelompok uji klien ke-11).
2. **Tidak ada endpoint/host penyedia di dalam APK.** Klien hanya memanggil path relatif (`/payments/config`, `/payments/order`, `/payments/claim`) ke server yang dikonfigurasi; pencarian `midtrans|xendit|duitku|tripay|dana.id|sandbox.` di seluruh berkas web APK tidak menemukan apa pun.
3. **Simulator pembayaran hanya hidup di server pengembangan**, dan hanya bila dua syarat benar-benar dipenuhi sekaligus: `EQ_PAYMENT_PROVIDER=sandbox` **dan** `EQ_ALLOW_INSECURE_DEV=1` pada listener loopback. Di APK tidak ada jalur `sandbox/settle` sama sekali.
4. **Server gagal-tertutup (fail closed).** Tanpa provider terkonfigurasi, semua endpoint pembayaran menjawab `503 PAYMENTS_NOT_CONFIGURED`; provider `dana` tanpa kredensial merchant menolak membuat checkout (`PROVIDER_NOT_READY`); webhook tanpa tanda tangan valid ditolak `401 INVALID_SIGNATURE`; status pending/gagal/kedaluwarsa/tidak dikenali tidak menerbitkan token.
5. **Premium hanya berasal dari server:** `isPremiumAccess()` menuntut `hasVerifiedAccess()` (status `verified` dari server) dan `mode==='premium'`; XP atau progres lokal tidak dapat membuka fitur Premium.

## 4. Cara memasang dan mengambil berkas

**A. Unduh berkas (paling mudah).** Buka berkas APK di penampil berkas sesi ini → tersedia tombol unduh. Berkas juga ada di `/home/user/artefak-apk/English-Quest-1.7.1-demo5-premium-debug.apk`.

**B. Kirim ke HP.** Salin APK ke HP (USB, Google Drive, atau aplikasi berbagi berkas), lalu di HP: **Setelan → Aplikasi → Akses khusus → Instal aplikasi tidak dikenal** → izinkan untuk aplikasi pengelola berkas Anda → ketuk APK → **Instal**.

**C. Lewat ADB (USB debugging aktif):**

```sh
adb devices
adb install -r English-Quest-1.7.1-demo5-premium-debug.apk
```

Jika pemasangan gagal dengan `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, berarti ada salinan lama dengan
tanda tangan debug berbeda — hapus dulu aplikasinya di HP (progres lokal bisa diekspor lebih dulu
lewat **Pengaturan → Ekspor progres**), lalu instal ulang. applicationId debug
(`com.englishquest.app.debug`) berbeda dari versi rilis, jadi keduanya bisa berdampingan.

**Verifikasi berkas setelah diunduh:**

```sh
sha256sum English-Quest-1.7.1-demo5-premium-debug.apk
# harapan: f3605181d063c18139b77da0e6ea676d2ba1079acc05bca098d3c3653667f1f0
```

**Membangun ulang dari source (jika berkas hilang):**

```sh
bash /home/user/setup_android_toolchain.sh          # menyiapkan JDK 17 + Android SDK 35 + Gradle
cd /home/user/english-quest/english-quest-android
JAVA_HOME=/var/tmp/eq/jdk17 ANDROID_HOME=/var/tmp/eq/android \
ANDROID_SDK_ROOT=/var/tmp/eq/android GRADLE_USER_HOME=/var/tmp/eq/gradle-home \
bash ./gradlew --no-daemon :app:assembleDebug
```

## 5. Jujur soal batas pengujian

- **Pembayaran DANA belum berfungsi dan belum diuji.** Belum ada kredensial merchant DANA, belum ada domain HTTPS publik untuk webhook, dan checkout DANA sengaja menolak dibuat. Jangan mengarahkan pengguna untuk membayar.
- APK yang diuji juga **belum diuji di perangkat nyata** dari sisi saya: lingkungan ini tidak punya akselerasi emulator (`/dev/kvm`), jadi yang saya verifikasi adalah hasil build, isi paket, tanda tangan, dan perilaku klien lewat pengujian otomatis (64 tes backend + 11 kelompok uji klien).
- Fitur yang butuh server (login, sinkronisasi kuota, token Premium) tidak dapat dipakai sampai origin API dikonfigurasi; tanpa itu aplikasi berjalan dalam demo lokal 5 soal dengan Premium terkunci.

## 6. Catatan penting soal penyimpanan berkas

Snapshot workspace dibatasi (sekitar 128 MB, sedangkan repo sudah memuat APK lama ±81 MB dan `.git`
±65 MB). Berkas APK 81 MiB di folder `artefak-apk` bisa saja **tidak ikut tersimpan** setelah sesi
berakhir — **unduh sekarang** bila ingin dipakai menguji di HP, atau bangun ulang dengan perintah di
atas. Saya tidak menghapus atau mengganti APK lama di repositori.
