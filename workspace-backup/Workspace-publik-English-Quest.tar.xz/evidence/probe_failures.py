#!/usr/bin/env python3
"""Read-only failure-path probe against the REAL English Quest handler.

Starts the unmodified backend handler in-process (no TLS, loopback dev mode as in
the project's own tests) and observes how it answers malformed / hostile requests.
No data is modified; the database is a throwaway temp file.
"""
import json
import os
import tempfile
import threading
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from backend import server as api

PEPPER = "probe-pepper-not-for-production-0123456789abcdef"

os.environ["EQ_ALLOW_INSECURE_DEV"] = "1"

tmp = tempfile.TemporaryDirectory()
store = api.Store(Path(tmp.name) / "probe.sqlite3", PEPPER)
server = ThreadingHTTPServer(("127.0.0.1", 0), api.Handler)
server.store = store
threading.Thread(target=server.serve_forever, daemon=True).start()
base = f"http://127.0.0.1:{server.server_address[1]}"


def call(method, path, data=None, headers=None, timeout=5):
    req = urllib.request.Request(base + path, data=data, method=method,
                                 headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as err:
        return err.code, err.read().decode("utf-8", "replace")
    except Exception as exc:  # connection-level failure
        return None, f"{type(exc).__name__}: {exc}"


def show(label, result):
    status, body = result
    snippet = body if len(body) <= 150 else body[:150] + "…"
    print(f"{label:<52} -> {status} | {snippet}")


print("=== FAILURE-PATH PROBE (backend unmodified) ===\n")

show("GET /api/health", call("GET", "/api/health"))
show("GET /api/unknown-endpoint (no auth)",
     call("GET", "/api/does-not-exist"))
show("GET /api/admin/summary (no auth)", call("GET", "/api/admin/summary"))
show("POST /api/register invalid JSON",
     call("POST", "/api/register", b"{not json",
          {"Content-Type": "application/json"}))
show("POST /api/register empty body, no Content-Length",
     call("POST", "/api/register"))
show("POST /api/register body > 32KB",
     call("POST", "/api/register", json.dumps({"email": "a" * 40000}).encode(),
          {"Content-Type": "application/json"}))
show("POST /api/register wrong Content-Type (text/plain, valid JSON)",
     call("POST", "/api/register", json.dumps({"email": "x@y.example", "password": "z" * 12}).encode(),
          {"Content-Type": "text/plain"}))
show("POST /api/premium/activate invalid token format (no auth)",
     call("POST", "/api/premium/activate", b'{"token":"BAD"}',
          {"Content-Type": "application/json"}))
show("POST /api/premium/activate valid format, no session",
     call("POST", "/api/premium/activate", b'{"token":"EQP-' + b"A" * 48 + b'"}',
          {"Content-Type": "application/json"}))
show("GET /api/me with garbage bearer",
     call("GET", "/api/me", headers={"Authorization": "Bearer " + "x" * 300}))
show("GET /api/me with no bearer", call("GET", "/api/me"))
show("GET /../etc/passwd (path traversal)",
     call("GET", "/..%2f..%2fetc%2fpasswd"))
show("GET /backend/server.py (sensitive source)",
     call("GET", "/backend/server.py"))
show("GET /backend/data/ (db dir)", call("GET", "/backend/data/"))
show("HEAD / (browser/proxy HEAD request)", call("HEAD", "/"))
show("GET /admin (dashboard html)", call("GET", "/admin"))
show("GET /tests/test_backend.py", call("GET", "/tests/test_backend.py"))

# ---- rate limiting behaviour on login ----
print("\n--- login rate limit (limit is 12 / 900s on the same IP) ---")
codes = []
for attempt in range(15):
    status, _ = call("POST", "/api/login",
                     json.dumps({"email": "nobody@example.test",
                                 "password": "wrong-password-1"}).encode(),
                     {"Content-Type": "application/json"})
    codes.append(status)
print("status codes 1..15:", codes)
print("429 appears after attempt:", codes.index(429) + 1 if 429 in codes else "NEVER")

# ---- session pruning behaviour on expired sessions ----
print("\n--- expired-session housekeeping ---")
with store.connection() as db:
    rows_before = db.execute("SELECT COUNT(*) n FROM sessions").fetchone()["n"]
    db.execute("UPDATE sessions SET expires_at='2000-01-01T00:00:00Z'")
    rows_expired_marked = db.execute(
        "SELECT COUNT(*) n FROM sessions WHERE expires_at<='2000-01-01T00:00:00Z'").fetchone()["n"]
store.account_status(store.authenticate(
    store.register("housekeeping@example.test", "correct-horse-47", "203.0.113.9")["session_token"]))
with store.connection() as db:
    rows_after = db.execute("SELECT COUNT(*) n FROM sessions").fetchone()["n"]
print(f"session rows before={rows_before}, marked-expired={rows_expired_marked}, after API call={rows_after}")

print("\n--- rate_limits table growth (never pruned?) ---")
with store.connection() as db:
    db.execute("INSERT INTO rate_limits(bucket,window_start,requests) VALUES('stale:bucket',1,5)")
    stale = db.execute("SELECT COUNT(*) n FROM rate_limits WHERE window_start < ?",
                       (0,)).fetchone()["n"]
    total = db.execute("SELECT COUNT(*) n FROM rate_limits").fetchone()["n"]
print(f"stale buckets older than epoch retained: still_present={stale>0}, total_buckets={total}")

tmp.cleanup()
print("\nProbe finished (no project files were modified).")
