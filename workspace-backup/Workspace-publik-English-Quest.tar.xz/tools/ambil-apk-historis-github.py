#!/usr/bin/env python3
"""Ambil kembali APK DEBUG HISTORIS yang salinan lokalnya dibersihkan.
Bukan APK owner-contact terbaru. Tidak memerlukan token untuk repository publik.
"""
from pathlib import Path
import hashlib
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'english-quest/English-Quest-1.7.1-debug.apk'
URL = 'https://raw.githubusercontent.com/bloxfruit6571-design/English-apk/502ec4c59d1d59cb19c29b8ff528e07412f53252/English-Quest-1.7.1-debug.apk'
SHA256 = '05e066414f831de225087d47bf00f3892810cc70b3343c5a228cfeda914bbd86'
SIZE = 85079299

def main():
    if DEST.exists():
        if DEST.stat().st_size == SIZE and hashlib.sha256(DEST.read_bytes()).hexdigest() == SHA256:
            print('APK historis sudah ada dan checksum benar.')
            return
        raise SystemExit('File tujuan sudah ada dengan isi berbeda; tidak ditimpa.')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    temp = DEST.with_suffix('.apk.download')
    digest = hashlib.sha256()
    size = 0
    try:
        with temp.open('xb') as output, urllib.request.urlopen(URL, timeout=30) as response:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                digest.update(chunk)
                size += len(chunk)
        if size != SIZE or digest.hexdigest() != SHA256:
            raise RuntimeError('Ukuran/checksum unduhan tidak cocok; file tidak dipasang.')
        if DEST.exists():
            raise RuntimeError('File tujuan muncul saat unduh; tidak ditimpa.')
        temp.rename(DEST)
        print('APK historis dipulihkan:', DEST)
    except FileExistsError:
        raise SystemExit('File sementara sudah ada; periksa unduhan sebelumnya dahulu.')
    except Exception:
        temp.unlink(missing_ok=True)
        raise

if __name__ == '__main__':
    main()
