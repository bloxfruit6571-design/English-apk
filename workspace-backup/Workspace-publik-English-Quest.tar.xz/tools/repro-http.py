"""Pemeriksaan sisi server untuk pendaftaran: konfigurasi CORS, HTTPS/proxy, dan penyimpanan akun.

Menjalankan instance backend terpisah dengan konfigurasi berbeda, memanggil endpoint pendaftaran,
lalu melaporkan status HTTP + header apa adanya. Semua kata sandi sintetis; database memakai file
sementara di /tmp dan dihapus lagi (tidak menyentuh database pengguna).
"""
import json
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = "/home/user/english-quest"
ORIGIN = "https://appassets.androidplatform.net"
PW = "ab12cd"        # 6 karakter (kontrak minimum)
PW_SHORT = "ab12c"   # 5 karakter, harus ditolak


def start_server(env_extra, port):
    env = dict(os.environ)
    env.update({
        "PYTHONPATH": ROOT,
        "EQ_HOST": "127.0.0.1",
        "EQ_PORT": str(port),
        "EQ_DB_PATH": os.path.join(tempfile.mkdtemp(prefix="eq-http-"), "db.sqlite3"),
        "EQ_TOKEN_PEPPER": secrets.token_hex(32),
    })
    env.update(env_extra)
    proc = subprocess.Popen([sys.executable, os.path.join(ROOT, "backend", "server.py")],
                            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    for _ in range(120):
        if proc.poll() is not None:
            return None, proc, "server keluar lebih awal: " + (proc.stderr.read() or "").strip()
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1)
            return proc, proc, ""
        except urllib.error.HTTPError:
            return proc, proc, ""          # server menjawab (mis. 400 HTTPS_REQUIRED) = sudah hidup
        except Exception:
            time.sleep(0.1)
    return None, proc, "server tidak siap dalam batas waktu"


def call(port, path, method="POST", body=None, origin=None, extra_headers=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if origin:
        req.add_header("Origin", origin)
    for k, v in (extra_headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            try:
                payload = json.loads(raw)
            except Exception:
                payload = {}
            return r.status, dict(r.headers), payload
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {}
        return e.code, dict(e.headers), payload


def run(label, env_extra, port, checks):
    print(f"\n== {label} (port {port}) ==")
    proc, handle, err = start_server(env_extra, port)
    if proc is None:
        print(f"  server TIDAK jalan → {err.splitlines()[-1] if err else 'tidak diketahui'}")
        return
    try:
        for name, fn in checks:
            try:
                print(f"  {name}: {fn(port)}")
            except Exception as exc:  # noqa: BLE001
                print(f"  {name}: ERROR {exc}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


# 1. Konfigurasi yang benar: dev loopback + origin APK diizinkan.
run(
    "A. Dev loopback + EQ_ALLOWED_ORIGINS berisi origin APK",
    {"EQ_ALLOW_INSECURE_DEV": "1", "EQ_ALLOWED_ORIGINS": ORIGIN},
    8101,
    [
        ("registrasi 6 karakter        ", lambda p: (lambda s, h, b: f"HTTP {s} ok={b.get('ok')} ACAO={h.get('Access-Control-Allow-Origin')}")(*call(p, "/api/register", body={"email": "ok-a@example.test", "password": PW}, origin=ORIGIN))),
        ("preflight OPTIONS            ", lambda p: (lambda s, h, b: f"HTTP {s} ACAO={h.get('Access-Control-Allow-Origin')} methods={h.get('Access-Control-Allow-Methods')}")(*call(p, "/api/register", method="OPTIONS", origin=ORIGIN))),
        ("kata sandi 5 karakter        ", lambda p: (lambda s, h, b: f"HTTP {s} code={b.get('code')} pesan=\"{b.get('message')}\"")(*call(p, "/api/register", body={"email": "short-a@example.test", "password": PW_SHORT}, origin=ORIGIN))),
        ("email tidak valid            ", lambda p: (lambda s, h, b: f"HTTP {s} code={b.get('code')}")(*call(p, "/api/register", body={"email": "bukan-email", "password": PW}, origin=ORIGIN))),
        ("email duplikat               ", lambda p: (lambda s, h, b: f"HTTP {s} code={b.get('code')}")(*call(p, "/api/register", body={"email": "ok-a@example.test", "password": PW}, origin=ORIGIN))),
        ("login akun yang baru dibuat ", lambda p: (lambda s, h, b: f"HTTP {s} ok={b.get('ok')}")(*call(p, "/api/login", body={"email": "ok-a@example.test", "password": PW}, origin=ORIGIN))),
    ],
)

# 2. EQ_ALLOWED_ORIGINS lupa diisi: server hidup, tetapi WebView tidak boleh membaca responsnya.
run(
    "B. Dev loopback TANPA EQ_ALLOWED_ORIGINS (lupa dikonfigurasi)",
    {"EQ_ALLOW_INSECURE_DEV": "1"},
    8102,
    [
        ("registrasi (Origin APK)      ", lambda p: (lambda s, h, b: f"HTTP {s} ok={b.get('ok')} ACAO={h.get('Access-Control-Allow-Origin')}  ← tanpa ACAO, WebView memblokir respons")(*call(p, "/api/register", body={"email": "ok-b@example.test", "password": PW}, origin=ORIGIN))),
    ],
)

# 3. Di belakang reverse proxy TLS tetapi header proto tidak diteruskan dengan benar.
run(
    "C. EQ_TRUST_PROXY=1 tanpa header X-Forwarded-Proto: https",
    {"EQ_TRUST_PROXY": "1"},
    8103,
    [
        ("tanpa X-Forwarded-Proto      ", lambda p: (lambda s, h, b: f"HTTP {s} code={b.get('code')} pesan=\"{b.get('message')}\"")(*call(p, "/api/register", body={"email": "ok-c@example.test", "password": PW}, origin=ORIGIN))),
        ("dengan X-Forwarded-Proto     ", lambda p: (lambda s, h, b: f"HTTP {s} ok={b.get('ok')}")(*call(p, "/api/register", body={"email": "ok-c@example.test", "password": PW}, origin=ORIGIN, extra_headers={"X-Forwarded-Proto": "https"}))),
    ],
)

# 3b. Batas percobaan pendaftaran per alamat IP (5 kali / 15 menit).
run(
    "E. Batas percobaan pendaftaran per IP",
    {"EQ_ALLOW_INSECURE_DEV": "1", "EQ_ALLOWED_ORIGINS": ORIGIN},
    8105,
    [("6 pendaftaran berurutan     ", lambda p: " | ".join(
        f"#{i}HTTP {call(p, '/api/register', body={'email': f'rate-{i}@example.test', 'password': PW}, origin=ORIGIN)[0]}"
        + (f" {call(p, '/api/register', body={'email': f'rate-{i}@example.test', 'password': PW}, origin=ORIGIN)[2].get('code')}" if False else "")
        for i in range(1, 7))
        + "  ← percobaan ke-6: " + str(call(p, '/api/register', body={'email': 'rate-7@example.test', 'password': PW}, origin=ORIGIN)[0])
        + " " + str(call(p, '/api/register', body={'email': 'rate-8@example.test', 'password': PW}, origin=ORIGIN)[2].get('code')))],
)

# 4. Mencoba melayani API ke jaringan tanpa TLS: server menolak start (bukan diam-diam HTTP).
env = dict(os.environ, PYTHONPATH=ROOT, EQ_HOST="0.0.0.0", EQ_PORT="8104",
           EQ_DB_PATH=os.path.join(tempfile.mkdtemp(prefix="eq-http-"), "db.sqlite3"),
           EQ_TOKEN_PEPPER=secrets.token_hex(32))
env.pop("EQ_ALLOW_INSECURE_DEV", None)
proc = subprocess.run([sys.executable, os.path.join(ROOT, "backend", "server.py")], env=env,
                      capture_output=True, text=True, timeout=30)
print("\n== D. EQ_HOST=0.0.0.0 tanpa TLS/proxy ==")
print(f"  exit={proc.returncode} | {proc.stderr.strip().splitlines()[-1] if proc.stderr.strip() else ''}")

for pattern in ("eq-http-",):
    for name in os.listdir(tempfile.gettempdir()):
        if name.startswith(pattern):
            shutil.rmtree(os.path.join(tempfile.gettempdir(), name), ignore_errors=True)
