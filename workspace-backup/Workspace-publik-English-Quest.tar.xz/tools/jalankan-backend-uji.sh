#!/usr/bin/env bash
# Menjalankan backend English Quest untuk menguji pendaftaran (khusus pengembangan lokal).
#
# Aman secara bawaan: hanya mendengarkan loopback (127.0.0.1), memakai berkas database uji
# terpisah, dan tidak menampilkan rahasia apa pun. Jangan pakai skrip ini untuk produksi —
# produksi memerlukan HTTPS/TLS (lihat LAPORAN-AKAR-MASALAH-PENDAFTARAN.md bagian konfigurasi).
set -euo pipefail

ROOT="${EQ_ROOT:-$(cd "$(dirname "$0")/../english-quest" && pwd)}"
PORT="${EQ_PORT:-8088}"
DB="${EQ_DB_PATH:-$HOME/.local/share/eq-uji-pendaftaran/db.sqlite3}"

mkdir -p "$(dirname "$DB")"

export EQ_HOST="${EQ_HOST:-127.0.0.1}"
export EQ_PORT="$PORT"
export EQ_DB_PATH="$DB"
export EQ_ALLOW_INSECURE_DEV=1                                  # diizinkan hanya karena loopback
export EQ_ALLOWED_ORIGINS="${EQ_ALLOWED_ORIGINS:-https://appassets.androidplatform.net}"

if [ -z "${EQ_TOKEN_PEPPER:-}" ]; then
  export EQ_TOKEN_PEPPER="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  echo "EQ_TOKEN_PEPPER: dibuat acak untuk sesi ini (nilainya sengaja tidak ditampilkan)."
else
  echo "EQ_TOKEN_PEPPER: memakai nilai dari lingkungan Anda."
fi

cat <<INFO
Backend uji siap dijalankan:
  alamat        : http://127.0.0.1:$PORT   (hanya loopback)
  database uji  : $DB
  origin diizinkan: $EQ_ALLOWED_ORIGINS

Untuk HP fisik lewat kabel USB (USB debugging aktif), sambungkan port-nya:
  adb reverse tcp:$PORT tcp:$PORT
Lalu pasang APK varian uji-lokal dan daftar akun seperti biasa.

Catatan: batas percobaan pendaftaran 5 kali / 15 menit per alamat IP.
INFO

cd "$ROOT/backend"
exec python3 server.py
