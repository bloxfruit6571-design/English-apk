#!/usr/bin/env bash
# Jalankan di Termux HP PEMILIK, bukan untuk mengirim credential ke Arena.
# Source + arsip workspace publik + APK debug. Tidak pernah push main atau menghapus file.
set -euo pipefail
BRANCH=audit-baseline-1.7.1
REPO=https://github.com/bloxfruit6571-design/English-apk.git
DOWNLOADS="${1:-$HOME/storage/downloads}"
APK=English-Quest-1.7.1-owner-contact-localtest-debug.apk
BUNDLE=English-Quest-97100ce.bundle
ARCHIVE=Workspace-publik-English-Quest.tar.xz
SUMS=SHA256SUMS-PUSH.txt
command -v pkg >/dev/null || { echo 'Jalankan skrip ini di Termux HP pemilik.' >&2; exit 1; }
pkg install -y git gh python coreutils
for file in "$APK" "$BUNDLE" "$ARCHIVE" "$SUMS"; do
  test -f "$DOWNLOADS/$file" || { echo "Unduh dahulu ke Downloads: $file" >&2; exit 1; }
done
(cd "$DOWNLOADS" && sha256sum --check "$SUMS")
python - "$DOWNLOADS/$APK" "$DOWNLOADS/$BUNDLE" <<'PY'
import hashlib,sys
expected=['372b126c4bd22c6665c7c5bd7aab741ab0194f213ed8a987024ba12d5f193a58','746da56a47ab81878b98b37c4afd2fdd8f1a3ebf003a222c2f90f10cea57ce11']
for path,want in zip(sys.argv[1:],expected):
    digest=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
    assert digest.hexdigest()==want, 'File APK/bundle berbeda; hentikan.'
print('Checksum APK/bundle cocok dengan hasil audit.')
PY
printf '\nLogin hanya pada browser sendiri. Jangan bagikan token, password atau device code.\n'
printf 'CLI dapat menyimpan token plaintext jika credential store tidak tersedia; jangan bagikan konfigurasi Termux.\n'
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
DEST=$(mktemp -d "$HOME/english-quest-push-XXXXXX")
git clone --branch "$BRANCH" --single-branch "$REPO" "$DEST/repo"
cd "$DEST/repo"
test "$(git branch --show-current)" = "$BRANCH"
git bundle verify "$DOWNLOADS/$BUNDLE"
git fetch "$DOWNLOADS/$BUNDLE" "$BRANCH"
# Berhenti bila riwayat divergen; tidak reset/force-push.
git merge --ff-only FETCH_HEAD
mkdir -p artefak-apk workspace-backup
cp "$DOWNLOADS/$APK" "artefak-apk/$APK"
cp "$DOWNLOADS/$ARCHIVE" "workspace-backup/$ARCHIVE"
cp "$DOWNLOADS/$SUMS" workspace-backup/
git add -- "artefak-apk/$APK" "workspace-backup/$ARCHIVE" "workspace-backup/$SUMS"
if ! git diff --cached --quiet; then
  LOGIN=$(gh api user --jq '.login')
  USER_ID=$(gh api user --jq '.id')
  git -c user.name="$LOGIN" -c user.email="$USER_ID+$LOGIN@users.noreply.github.com" commit -m 'Archive owner debug APK and reviewed public workspace backup'
fi
git push origin "HEAD:refs/heads/$BRANCH"
COMMIT=$(git rev-parse HEAD)
REMOTE=$(git ls-remote origin "refs/heads/$BRANCH" | awk '{print $1}')
test "$COMMIT" = "$REMOTE"
python - "$COMMIT" "$DOWNLOADS/$ARCHIVE" <<'PY'
import hashlib,sys,urllib.request
from pathlib import Path
commit=sys.argv[1]
checks={
 'artefak-apk/English-Quest-1.7.1-owner-contact-localtest-debug.apk':'372b126c4bd22c6665c7c5bd7aab741ab0194f213ed8a987024ba12d5f193a58',
 'workspace-backup/Workspace-publik-English-Quest.tar.xz':hashlib.sha256(Path(sys.argv[2]).read_bytes()).hexdigest(),
 'English-Quest-1.7.1-debug.apk':'05e066414f831de225087d47bf00f3892810cc70b3343c5a228cfeda914bbd86',
}
for path,want in checks.items():
    url='https://raw.githubusercontent.com/bloxfruit6571-design/English-apk/'+commit+'/'+path
    digest=hashlib.sha256();size=0
    with urllib.request.urlopen(url,timeout=60) as response:
        while True:
            chunk=response.read(1024*1024)
            if not chunk:break
            digest.update(chunk);size+=len(chunk)
    assert digest.hexdigest()==want, 'Checksum remote tidak cocok: '+path
    print('VERIFIKASI GITHUB PASS:',path,size,'byte',want)
print('PUSH DAN UNDUH-ULANG TERVERIFIKASI. Commit:',commit)
PY
printf '\nTidak ada file HP/workspace dihapus oleh skrip ini.\n'
printf 'Kirim hanya commit di atas atau pesan SUDAH; jangan kirim credential.\n'
printf 'Asisten kemudian dapat memeriksa GitHub sendiri sebelum menghapus salinan APK di workspace.\n'
