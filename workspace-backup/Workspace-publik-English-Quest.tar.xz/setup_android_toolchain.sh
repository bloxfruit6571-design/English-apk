#!/usr/bin/env bash
# Toolchain bootstrap for the English Quest Android build.
# Everything is installed OUTSIDE /home/user on purpose: the workspace snapshot must stay
# small, and a JDK/SDK is a re-downloadable build dependency, not part of the project.
set -euo pipefail

ROOT=/var/tmp/eq
JDK_DIR="$ROOT/jdk17"
SDK_DIR="$ROOT/android"
GRADLE_HOME_DIR="$ROOT/gradle-home"
mkdir -p "$ROOT"

step() { echo; echo "=== $* ==="; }

step "1/4 JDK 17 (Temurin)"
if [ ! -x "$JDK_DIR/bin/javac" ]; then
  JDK_URL=$(curl -s "https://api.adoptium.net/v3/assets/latest/17/hotspot?architecture=x64&image_type=jdk&os=linux&vendor=eclipse" \
    | python3 -c "import json,sys; d=json.load(sys.stdin); print(d[0]['binary']['package']['link'])")
  echo "unduh: $JDK_URL"
  curl -sL --max-time 900 -o /tmp/jdk17.tar.gz "$JDK_URL"
  mkdir -p "$JDK_DIR"
  tar -xzf /tmp/jdk17.tar.gz -C "$JDK_DIR" --strip-components=1
  rm -f /tmp/jdk17.tar.gz
fi
"$JDK_DIR/bin/java" -version 2>&1 | head -2

step "2/4 Android command-line tools"
if [ ! -x "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -sL --max-time 900 -o /tmp/cmdline-tools.zip \
    "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  mkdir -p "$SDK_DIR/cmdline-tools"
  unzip -q /tmp/cmdline-tools.zip -d "$SDK_DIR/cmdline-tools"
  mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
  rm -f /tmp/cmdline-tools.zip
fi
echo "sdkmanager: $("$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --version 2>/dev/null)"

step "3/4 SDK platform 35 + build-tools 35.0.0 + platform-tools"
export JAVA_HOME="$JDK_DIR"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
yes | "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
"$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --install \
  "platform-tools" "platforms;android-35" "build-tools;35.0.0" 2>&1 | tail -3
ls "$SDK_DIR/platforms" "$SDK_DIR/build-tools"

step "4/4 Gradle build (assembleDebug)"
export GRADLE_USER_HOME="$GRADLE_HOME_DIR"
cd /home/user/english-quest/english-quest-android
bash ./gradlew --no-daemon --console=plain :app:assembleDebug 2>&1 | tail -40

echo
echo "=== HASIL BUILD ==="
find /home/user/english-quest/english-quest-android/app/build/outputs -name '*.apk' -printf '%p  %s byte\n' 2>/dev/null || echo "tidak ada APK"
echo "BOOTSTRAP_DONE"
