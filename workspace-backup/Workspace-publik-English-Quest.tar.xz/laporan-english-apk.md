# Laporan Pemeriksaan Repositori

**Target:** https://github.com/bloxfruit6571-design/English-apk
**Tanggal pemeriksaan:** 15 Oktober 2026
**Metode:** clone read-only (tidak ada file repo yang diubah), pembacaan source, penguraian isi APK, dan menjalankan test suite milik repo.

---

## 1. Data repositori

| Item | Nilai |
|---|---|
| Pemilik | `bloxfruit6571-design` (akun user, ID 342821722) |
| Status | Publik, bukan fork, deskripsi kosong, tanpa topik |
| Dibuat | 15 Okt 2026, 04:13 UTC (= 11:13 WIB) |
| Push terakhir | 15 Okt 2026, 04:38 UTC — jadi repo masih sangat baru (beberapa jam sebelum pemeriksaan) |
| Branch / tag / release | 1 branch (`main`) / 0 tag / 0 release |
| Commit | 2 |
| Stars / forks / watchers / issues | 0 / 0 / 0 / 0 |
| Lisensi | **Tidak ada** (`license: null`, tidak ada file `LICENSE`) |
| Bahasa utama (menurut GitHub) | Python |
| Ukuran di GitHub | ± 65 MB (terkompres) |
| Ukuran setelah di-clone | 157 MB (yang 85 MB adalah APK) |
| Jumlah file (tanpa `.git`) | 71 (semua ter-track oleh git) |

**Riwayat commit:**

1. `a44fc38` — "Initial commit" — oleh **bloxfruit6571-design &lt;bloxfruit6571@gmail.com&gt;** (email pribadi tampil publik), hanya menambah `README.md` 1 baris.
2. `d05e4e6` — "Publish English Quest 1.7.1 project" — oleh **English Quest Project &lt;english-quest-project@users.noreply.github.com&gt;** (nama/email berbeda dari commit pertama), menambah 71 file / 10.404 baris.

> Catatan: dua identitas commit berbeda. Commit pertama memakai email Gmail asli, commit kedua memakai identitas "project" anonim. Bukan indikasi malware, hanya perlu diketahui untuk penelusuran asal-usul.

---

## 2. Apa isi repo ini: "English Quest 1.7.1"

Aplikasi belajar bahasa Inggris (materi penjelasan berbahasa Indonesia, target materi bahasa Inggris), offline-first, tersedia dalam **dua bentuk sekaligus**:

- **PWA web statis** (`index.html` + JS/CSS di root), dan
- **APK Android WebView** (`English-Quest-1.7.1-debug.apk` di root repo, di-build dari folder `english-quest-android/`).

Struktur folder:

```
/                     → PWA statis + APK + ikon + data materi
├── backend/          → API Python + SQLite + dashboard admin
├── english-quest-android/  → proyek Gradle Android (wrapper WebView)
├── images/           → potret karakter (webp/png)
├── image-search/     → 8 gambar referensi hasil pencarian gambar (tidak dipakai aplikasi)
├── source-art/characters/ → 3 PNG sumber (Aki, Rina, Suki)
└── tests/            → unittest Python + test Node
```

### Isi tiap bagian

**A. Aplikasi web / PWA**

| File | Baris | Fungsi |
|---|---|---|
| `app.js` | 2.368 | Seluruh logika UI: 43 view/halaman, navigasi, profil, progres, kuis, misi, akses |
| `styles.css` | 235 | Tema tampilan |
| `library-data.js` | 242 | 17 artikel perpustakaan |
| `mission-data.js` | 307 | Bank misi global |
| `mission-data-extras.js` | 184 | Tambahan misi |
| `access-client.js` | 99 | Klien sesi/Premium ke server |
| `sw.js` | 26 | Service Worker (cache offline, sengaja **tidak** meng-cache `/api` dan `/admin`) |
| `manifest.webmanifest`, `icon.*`, `index.html` | — | PWA installable |

**B. Konten pembelajaran (hasil hitung langsung dari file, bukan sekadar klaim README)**

- **6 level, 30 pelajaran** (tepat 5 per level): Basic English → Basic Sentences → … → level 6 lanjutan.
- Setiap pelajaran berisi: penjelasan, 5 kosakata (V), 3 contoh (E), cerita, dialog (total 65 blok dialog), latihan berprompt (44 objek), dan kuis.
- ✔ **89 misi / 445 soal** — Easy 25 misi (125 soal), Medium 25 (125), Hard 29 (145), Mode Bule 10 (50). Persis sama dengan klaim README.
- ✔ **17 artikel perpustakaan**: Grammar 11, Kosakata 2, Speaking 2, Reading 1, Writing 1.
- **5 karakter** lokal: Aki, Rina, Bimo, Naya, Suki (+ Character Creator).
- Fitur lain: Story Mode, Suki Showdown, Listening Detective, Word Hunter, Grammar Puzzle/Battle, Picture Quiz, Speed Quiz, kamus + bookmark, statistik/XP/streak, ekspor JSON, mode Easy/Medium/Hard/Mode Bule, TTS, latihan mikrofon.

**C. Backend (`backend/`, hanya Python standard library + SQLite)**

- `server.py` (767 baris) — API JSON 12 endpoint: `health`, `register`, `login`, `logout`, `me`, `demo/start`, `demo/sync`, `demo/consume`, `premium/activate`, `admin/summary`, `admin/tokens`, `admin/tokens/revoke`.
- Kata sandi: PBKDF2-HMAC-SHA-256, 310.000 iterasi + salt unik. Sesi: bearer 256-bit acak, disimpan sebagai hash, masa berlaku 30 hari.
- Token Premium: format `EQP-` + 48 digit hex, disimpan sebagai HMAC-SHA-256 dengan pepper server (`EQ_TOKEN_PEPPER`), klaim memakai transaksi `BEGIN IMMEDIATE` (aman dari race), hanya bisa diklaim 1 akun, plaintext hanya tampil sekali.
- Ada rate limit pada register/login/claim/sync/demo, access log dimatikan (agar kredensial tidak masuk log), HTTP polos ditolak kecuali mode dev loopback.
- `admin.html` (48 baris) — dashboard admin token (buat 1–500 token, filter status, revoke). `manage.py` — perintah `create-admin`.

**D. Proyek Android (`english-quest-android/`)**

- Gradle 8.9, AGP 8.7.3, `compileSdk 35`, `minSdk 23`, `targetSdk 35`, versionCode 13, versionName `1.7.1`.
- `MainActivity.java` (1.239 baris) — wrapper `WebView` dari aset lokal (`https://appassets.androidplatform.net/assets/index.html`).
- **Izin hanya 2:** `INTERNET` dan `RECORD_AUDIO` (+ fitur mikrofon `required=false`). Tidak ada izin kontak, SMS, lokasi, kamera, atau package lain.
- Pengerasan keamanan WebView yang memang aktif: `setAllowFileAccess(false)`, `MIXED_CONTENT_NEVER_ALLOW`, `usesCleartextTraffic="false"`, `allowBackup="false"`.
- Jembatan JS→native (`@JavascriptInterface`) hanya untuk: buka tautan eksternal, baca/tulis profil cadangan (SharedPreferences), cek & jalankan pengenalan suara, dan TTS.
- `openExternal()` **whitelist domain**: hanya `*.wikipedia.org` dan `*.creativecommons.org` yang boleh dibuka di browser; URL lain diabaikan.
- Model suara offline **Vosk** (`vosk-model-small-en-us-0.15.zip`, 41 MB) dibundel di APK dan diunduh saat build dengan verifikasi SHA-256.

**E. Test yang disertakan**

- `tests/test_backend.py` (377 baris, 16 test) — API, migrasi DB, kuota demo, idempotensi sync, klaim token atomik, gate admin.
- `tests/client_gates.test.js` (255 baris) — 10 grup acceptance (demo lokal, kuota 10/restart, submit ganda, Premium fail-closed, retensi progres, peran admin) + smoke test 43 renderer halaman.

---

## 3. Hasil verifikasi independen yang saya lakukan

| Yang diklaim README | Hasil cek saya |
|---|---|
| SHA-256 APK `05e06641…bbd86` | ✔ **Cocok persis** (dihitung ulang: 85.079.299 byte) |
| APK = 17 aset desain web identik byte-for-byte dengan source | ✔ **Cocok 17/17** (app.js, styles.css, index.html, sw.js, 3 data JS, manifest, 3 ikon, 5 karakter) |
| Model Vosk SHA-256 `30f26242…42498` | ✔ **Cocok persis** dengan pin di `build.gradle` **dan** dengan zip di dalam APK |
| 16 backend test lulus | ✔ Saya jalankan: **16/16 OK** (3,2 detik) |
| 10 grup client gate + smoke 43 renderer lulus | ✔ Saya jalankan: **lulus**, exit code 0 |
| 89 misi / 445 soal | ✔ **Terverifikasi persis** |
| 17 artikel perpustakaan | ✔ **Terverifikasi** |
| 30 pelajaran / 6 level | ✔ **Terverifikasi** (5 pelajaran per level) |
| Package `com.englishquest.app.debug`, versi `1.7.1-debug`, APK debug | ✔ Terkonfirmasi dari dalam APK; sertifikat penandatangan `CERT.RSA` = **"Android Debug"** key, flag `debuggable` aktif |

**Pemeriksaan keamanan (hasil: bersih):**

- Tidak ada `eval(`, `new Function`, `child_process`, `subprocess`, `os.system`, `curl/wget` di source.
- **Tidak ada analytics/tracker** sama sekali — tidak ada Firebase, Google Analytics/gtag, Sentry, Mixpanel, Facebook SDK.
- **Tidak ada domain asing yang dihubungi otomatis.** Satu-satunya `fetch()` jaringan di `app.js` adalah Wikipedia REST API, dan itu hanya saat pengguna sendiri membuka halaman "Sumber Belajar". Domain lain di repo hanya: `w3.org` (namespace SVG), `alphacephei.com` (unduh model Vosk saat build), `appassets.androidplatform.net` (origin WebView lokal).
- Tidak ada `document.cookie`, keylogger, akses SMS/kontak, `AccessibilityService`, instalasi paket, atau `QUERY_ALL_PACKAGES`.
- `.gitignore` rapi: mengecualikan `.env`, DB SQLite, keystore, `.netrc`, `.git-credentials`, folder `uploads/`.
- Tidak ada kredensial/secret yang ter-commit (tidak ada `.env`, DB, atau file keystore).

---

## 4. Catatan, keterbatasan, dan hal yang perlu diperhatikan

1. **Backend production belum ada.** `EQ_API_BASE_URL` di APK sengaja kosong. Akibatnya: login/sinkronisasi akun dan aktivasi Premium **tidak akan berfungsi** di APK ini. Yang jalan hanya demo lokal 10 soal. README sendiri menyatakan "production belum dikonfigurasi atau dideploy".
2. **Demo lokal bukan anti-tamper.** Penulis mengakui kuota demo lokal bisa di-reset dengan menghapus data aplikasi. Ini wajar untuk fallback offline, tapi jangan dianggap pembatasan yang kuat.
3. **APK bertanda debug key** dan `debuggable=true` → hanya untuk sideload/uji coba, **bukan** untuk distribusi Play Store atau penggunaan produksi.
4. **Belum ada lisensi.** Tanpa file `LICENSE`, status hukum pemakaian ulang kode ambigu — secara default "all rights reserved". Materi/aset juga perlu diperhatikan:
   - Model Vosk & pustaka Vosk: Apache-2.0 (aman, ada notice di `vosk-model-notice.txt`).
   - Folder `image-search/` berisi 8 gambar referensi (gaya ilustrasi anime) hasil pencarian gambar tanpa atribusi sumber; ada juga potret karakter tanpa keterangan asal. **Tidak ada informasi lisensi/atribusi untuk aset karakter** — ini titik risiko hak cipta jika aplikasi dipublikasikan.
5. **Belum diuji di perangkat nyata.** Penulis menyatakan mikrofon, ASR (Vosk), TTS, dan SFX belum pernah diuji di HP/emulator karena perangkat tidak tersedia; yang ada hanya test HTTP lokal dan Node VM. Jadi fungsi inti suara **belum terbukti berjalan**.
6. **Backend bersifat single-node.** SQLite + HTTP server standard library, ditujukan untuk integrasi awal, bukan skala besar. Pepper token wajib dijaga/di-backup (kalau berganti, token yang belum diklaim hilang).
7. **Dua identitas commit berbeda** (lihat bagian 1) dan repo baru berumur beberapa jam dengan 0 bintang — belum ada riwayat/track record.
8. Tidak ada GitHub Actions/CI, tidak ada rilis bertag, tidak ada `package.json` (semua modul JS dimuat via tag `<script>` klasik).

---

## 5. Kesimpulan singkat

Repo ini berisi **proyek aplikasi edukasi lengkap dan cukup matang secara struktur**: PWA + APK Android + backend akun/Premium + 2 test suite, dengan konten yang jumlahnya **benar-benar sesuai klaim README** (30 pelajaran, 89 misi/445 soal, 17 artikel) dan hash APK/model yang **dapat diverifikasi ulang**. Hasil scan keamanan bersih: tanpa tracker, tanpa domain mencurigakan, izin Android minimal, dan whitelist tautan eksternal yang ketat.

Yang membuatnya belum bisa dipakai sebagai produk: **backend belum dideploy** (akun & Premium mati), **APK masih debug key**, **tidak ada lisensi**, dan **fitur suara belum pernah diuji di perangkat asli**. Untuk sekadar mencoba belajar offline, APK-nya bisa dipasang (sideload) dan demo 10 soal berjalan; untuk pemakaian serius, tiga hal pertama di atas harus dibereskan lebih dulu.

*(Tidak ada file di repositori yang saya ubah — pemeriksaan dilakukan pada salinan clone terpisah.)*
