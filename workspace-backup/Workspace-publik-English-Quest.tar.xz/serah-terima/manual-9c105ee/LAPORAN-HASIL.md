# Hasil implementasi lokal — Premium DANA manual

**18 Oktober 2026 · English Quest · Belum online / belum dipush**

Alur baru telah diimplementasikan, diuji dan dicommit lokal: **Rp5.000 sekali bayar, permanen** →
permintaan pembeli → pemeriksaan transaksi DANA oleh admin → penerbitan satu token → aktivasi pembeli.
Tidak ada uang nyata, kredensial produksi, deployment atau pembelian layanan yang digunakan.

## 1. Branch dan commit yang benar-benar diperiksa

| Komponen | Hasil |
|---|---|
| Branch kerja | `audit-baseline-1.7.1` |
| Remote audit, pemeriksaan terakhir | `502ec4c59d1d59cb19c29b8ff528e07412f53252` |
| Remote main, tidak disentuh | `d05e4e6783131ea96734ce60889f05c1aa852305` |
| Baseline source lokal yang dipakai | `606402771d73f5c5519c8c3965f4b1431a31596e` — persiapan hosting/HTTPS terdahulu |
| Commit manual baru | **`9c105ee21122952708a8f0fcf75cc23e08243d26`** |
| Pesan commit | `Add manual DANA verification and one-time account-bound Premium issuance` |
| Perubahan manual sejak 6064027 | 22 berkas, 1.312 penambahan baris, 38 penghapusan baris; tidak ada berkas dihapus |

Commit berada di checkout audit `/home/user/.cache/eq-manual` saat pekerjaan selesai. Karena direktori
cache tidak dipertahankan lintas snapshot, commit juga disimpan sebagai **bundle Git terverifikasi**.
Source aktif `/home/user/english-quest` tetap ada tanpa `.git`; **123 berkas tracked cocok byte-for-byte**
dengan checkout commit baru. Tidak ada perbaikan lama yang sengaja dibatalkan.

Remote telah diperiksa kembali melalui `git ls-remote`; belum berubah. Tidak mencoba menggunakan PAT
yang pernah terpapar dan tidak mengulangi push tanpa autentikasi aman. Commit lokal bukan bukti push.

## 2. Hasil sesuai persyaratan

| Persyaratan | Implementasi / hasil uji |
|---|---|
| Harga dan penerima | Rp5.000 tetap di server; sekali/permanen/tanpa langganan; nomor/nama dari konfigurasi; tombol salin |
| Konfigurasi kosong | Pembayaran dinonaktifkan dengan pesan jelas; tidak mengarang nomor/nama |
| Tombol pembeli | Membuat pending dengan ID pesanan/akun; **tidak memberi token atau Premium** |
| Bukti pembayaran | Admin wajib memeriksa transaksi DANA masuk; screenshot/pernyataan pembeli bukan bukti final |
| Admin | Login + pemeriksaan role backend; daftar, cari/filter, verifikasi, tolak, terbitkan, status token/aktivasi, audit |
| Nominal salah | Ditolak, termasuk nilai string/boolean; jumlah yang diterima harus integer 5000 |
| Token hanya sesudah verifikasi | Pending/rejected tidak dapat menerbitkan token |
| Tidak ganda | Enam penerbitan bersamaan hanya menghasilkan satu kode/token; retry tidak merotasi kode |
| Pemilik akun | Pesanan tidak dapat dibaca akun lain; token hanya dapat diaktifkan akun pemilik pesanan |
| Permanent | Tidak ada expiry; Premium bertahan setelah logout/login, pembukaan Store ulang, dan backup/restore |
| Hash / fail closed | Tidak ada plaintext token dalam DB; server gagal tidak memberi Premium; rollback atomik diuji |
| Migrasi | Tiga tabel tambahan + indeks; baris pengguna/sesi/token/pesanan lama tetap sama |
| Konten/versi | Materi, navigasi, identitas dan versionCode/versionName tidak diubah oleh commit manual |

Tidak semua aspek dapat dibuktikan otomatis: server tidak tersambung ke DANA untuk memastikan dana
masuk. Kejujuran/ketelitian admin dan pencocokan transaksi nyata tetap menjadi tanggung jawab pemilik.

## 3. Berkas dan database

Berkas inti:
- `backend/manual_payments.py`: konfigurasi, migrasi aditif, ownership, transaksi admin, receipt HMAC,
  penerbitan satu kali dan audit.
- `backend/server.py`: endpoint, guard alur otomatis produksi, pengikatan token ke pemilik, audit aktivasi/pencabutan.
- `backend/admin.html`: dashboard manual; formulir pemeriksaan dana, kode sekali tampil, batas waktu jaringan.
- `app.js`, `access-client.js`, `sw.js`: UI/API manual, pemulihan status, pembersihan saat logout, cache v20.
- Salinan ketiga aset tersebut di Android disinkronkan; parity keseluruhan **17 aset** lulus.
- `tests/test_manual_payments.py`, `tests/client_manual_payments.test.js`: tes baru.
- `README.md`, `PEMBAYARAN-DANA-MANUAL.md`, arsip `PREMIUM_PEMBAYARAN.md`, dokumen/env/checker deployment.
- Lima berkas bukti uji di `evidence/manual/`.

Daftar lengkap tersedia pada `DAFTAR-PERUBAHAN.txt`.

Migrasi `manual_dana_v1` menambahkan `manual_payment_orders`, `manual_payment_audit`,
`eq_schema_migrations`. Tabel/ledger lama tidak dihapus atau dibangun ulang. Harga/currency memiliki
CHECK, receipt dan token unik, satu pesanan aktif per akun. Snapshot penerima disimpan pada pesanan.
Aktivasi tetap menggunakan `premium_tokens` lama dan transaksi yang sudah ada.

**Tidak ada DB pengguna/produksi yang dibuka atau dimigrasikan pada pekerjaan ini.** Tes memakai
fixture sementara sintetis. Migrasi pada data sungguhan tetap memerlukan backup dan persetujuan.

## 4. Endpoint aktif baru

- Publik HTTPS: `GET /api/manual-payments/config`.
- Akun permanen: `POST /api/manual-payments/orders`, `GET /api/manual-payments/orders`,
  `GET /api/manual-payments/order?order_id=…` (hanya milik sendiri).
- Admin: `GET /api/admin/manual-payments`, `GET /api/admin/manual-payments/audit?order_id=…`,
  `POST /api/admin/manual-payments/verify`, `/reject`, `/issue`.
- Aktivasi tetap `POST /api/premium/activate`; summary admin ditambah metrik manual.

Semua `/api/payments/*` HTTP lama dan POST penerbitan token generik `/api/admin/tokens` diblokir
pada produksi. Pengecualian eksplisit hanya untuk regresi lama di loopback insecure-dev. Renderer/
adapter lama tidak dihapus untuk kompatibilitas; **klien terbaru menggunakan manual**. Delapan berkas
tes baseline tetap identik, bukan diubah untuk meloloskan implementasi baru.

## 5. Bukti verifikasi

| Pemeriksaan akhir | Hasil |
|---|---|
| Seluruh unittest Python di checkout commit | **102 lulus, 0 gagal, 0 skipped** |
| Cakupan Python baru | 28 tes: Store, konfigurasi, HTTP, TLS nyata lokal, migrasi dan backup/restore |
| Node UI manual | **10 kelompok lulus**, memakai app/client/admin script asli di DOM stub |
| Node registrasi lama | 13 kelompok lulus, termasuk backend nyata |
| Node failure paths lama | 8 kelompok lulus |
| Node gates lama | 11 kelompok + seluruh 43 renderer lulus |
| Web–Android parity | **17 berkas identik**, cache `english-quest-shell-v20` |
| Reproduksi klien HTTPS lokal | Lulus dengan CA fixture dipercaya; bukan TLS verification dimatikan |
| Simulator otomatis lama | 18 langkah lulus, **hanya tes kompatibilitas lokal**, bukan alur produksi |
| Sintaks | Python compile + Node check app/client/SW/admin lulus |
| Git | `diff --check`, `fsck`, `bundle verify` lulus |
| Pemeriksaan pola kredensial | Tidak ditemukan PAT/private key/kode Premium plaintext pada berkas berubah |

Dependensi `cryptography` dipasang di sandbox untuk menjalankan tes adapter DANA lama tanpa skip.
Alur manual runtime sendiri tidak memerlukan merchant API atau dependensi kriptografi tambahan.
Tes pertama sempat memiliki satu skip sebelum paket tersebut dipasang; **hasil akhir di atas tidak**.

Alur HTTPS lokal menguji pendaftaran password enam karakter, pending tanpa entitlement, admin
verifikasi, penerbitan, aktivasi, logout/login dan persistensi Premium. Pengujian UI menggunakan
Node VM, **bukan pengujian visual/browser Android atau HP nyata**.

Reproduksi suite utama:

```sh
PYTHONPATH=. python3 -m unittest discover -s tests -p 'test_*.py' -v
for test in tests/*.test.js; do node "$test"; done
```

OpenSSL dibutuhkan untuk fixture TLS; `cryptography` opsional diperlukan agar tes kriptografi legacy
tidak dilewati. Bukti terperinci tersimpan di `evidence/manual/` dalam commit/bundle.

## 6. Paket serah-terima kecil

| Berkas | Fungsi |
|---|---|
| `English-Quest-9c105ee.bundle` | **94.722 byte**; commit 6064027 dan 9c105ee, membutuhkan basis 502ec4c |
| `English-Quest-502ec4c-ke-9c105ee.patch` | 349.468 byte; alternatif patch dua commit sejak 502ec4c |
| `SHA256SUMS.txt` | Hash kedua artefak |
| `VERIFIKASI-BUNDLE.txt` | Hasil validasi Git |
| `DAFTAR-PERUBAHAN.txt` | Daftar perubahan manual sejak baseline 6064027 |
| `PANDUAN-ADMIN-MANUAL.md` | Panduan operasional/config/endpoint dan batasan |

Tidak membuat ulang arsip source besar atau APK. Bundle incremental tidak menggandakan APK lama.
Gunakan **bundle atau patch**, jangan keduanya diterapkan berurutan.

Untuk melanjutkan push dari HP pemilik, gunakan panduan Termux/browser login terdahulu di
`../hosting-6064027/PANDUAN-HP-ANGGARAN-NOL.md`, tetapi ganti bundle/commit dengan 9c105ee ini.
Jangan kirim PAT/password/kode login ke percakapan. PAT yang pernah terpapar tetap harus dicabut.

Pada clone bersih pemilik yang telah memuat basis 502ec4c, setelah mengunduh bundle ke path lokal:

```sh
git status --short
# Jika ada perubahan lokal, BERHENTI dan amankan perubahan itu dahulu.
git switch audit-baseline-1.7.1
git bundle verify /path/ke/English-Quest-9c105ee.bundle
git fetch /path/ke/English-Quest-9c105ee.bundle refs/heads/audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
git log -1 --oneline
# Harus menunjukkan 9c105ee. Setelah login browser langsung pada perangkat sendiri:
git push origin audit-baseline-1.7.1
```

`/path/ke/…` adalah penanda path berkas unduhan, bukan perintah yang boleh disalin tanpa disesuaikan.
Jika merge fast-forward ditolak, jangan force/reset/main: periksa perubahan remote terlebih dahulu.

## 7. Yang belum selesai / persetujuan berikutnya

1. **Nomor dan nama DANA masih kosong.** Pembayaran sengaja belum tersedia. Isi hanya setelah pemilik
   mengonfirmasi penerima yang sah; jangan menerima pembayaran melalui fixture tes.
2. **Belum push.** Autentikasi aman pada perangkat pemilik masih diperlukan; izin push audit sudah ada.
3. **Belum hosting/deploy publik.** Anggaran nol dan perangkat Android saja tetap dihormati. Tidak ada
   layanan/domain dibeli. Solusi harus punya HTTPS dan penyimpanan SQLite persisten serta backup;
   filesystem ephemeral bukan penyimpanan permanen.
4. Origin nyata `EQ_API_BASE_URL`, `EQ_ALLOWED_ORIGINS`, pepper stabil `EQ_TOKEN_PEPPER`, path DB dan
   backup perlu ditetapkan saat deployment yang disetujui. Tidak ada URL/secret produksi dikarang.
5. Proxy template publik masih memblokir admin. Jalur admin privat HTTPS/VPN perlu disiapkan tanpa
   membuka backend HTTP atau menghapus autentikasi.
6. Tetapkan kanal privat untuk menyerahkan kode dan kebijakan kode hilang/refund. **Kode tampil sekali**;
   jika respons hilang sesudah commit, retry tidak mengeluarkan kode lain. Tidak ada recovery plaintext.
7. **Tidak ada APK baru.** Package/version tetap; APK lama tidak memuat perubahan ini. Build/signing
   dan uji di HP nyata menunggu origin HTTPS yang benar dan persetujuan yang diperlukan.
8. Uji publik pendaftaran → pembayaran manual → admin → aktivasi → buka ulang HP belum dilakukan.
   Tidak boleh disebut siap online sebelum tahap itu selesai.
