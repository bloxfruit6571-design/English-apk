# Hasil akhir — Premium DANA + WhatsApp

**18 Oktober 2026 · Implementasi lokal, tes, APK debug dan pembersihan selesai. GitHub belum terbarui.**

## Unduhan

- [APK debug terbaru](../../artefak-apk/English-Quest-1.7.1-dana-whatsapp-localtest-debug.apk)
- [Checksum APK](../../artefak-apk/English-Quest-1.7.1-dana-whatsapp-localtest-debug.apk.sha256)
- [Panduan instalasi dan pengujian HP](PANDUAN-HP.md)
- [Backend lokal untuk Termux](English-Quest-backend-dana-whatsapp.zip)
- [Bundle Git pemulihan](English-Quest-62e9357.bundle) · [patch alternatif](English-Quest-502ec4c-ke-62e9357.patch)
- [Checksum bundle/patch/backend](SHA256SUMS.txt)

## A. Branch, commit dan status GitHub

Pemeriksaan dilakukan terhadap source dan Git nyata, bukan hanya laporan lama.

| Item | Hasil |
|---|---|
| Branch kerja | `audit-baseline-1.7.1` |
| Remote audit yang diperiksa | `502ec4c59d1d59cb19c29b8ff528e07412f53252` |
| Baseline lokal yang dipulihkan dari bundle | `c8301ad6453fd45ea79d8c1466b674b7473c52bb` |
| Commit baru | **`62e9357c95a04e8c0bcabaa4a8c5e0cec0721a6f`** |
| Pesan commit | `Simplify Premium to DANA and WhatsApp with secure manual admin issuance` |
| Main remote | `d05e4e6783131ea96734ce60889f05c1aa852305`, tidak diubah |
| Push | **Gagal exit 128**, autentikasi aman tidak tersedia; terminal prompts disabled |

Push c8301ad ke audit dicoba sebelum perubahan, sesuai urutan permintaan. Konektor GitHub juga
melaporkan unsupported. Tidak menggunakan PAT terpapar, tidak meminta token/password lewat chat,
dan tidak memaksakan retry tanpa autentikasi. Setelah kegagalan push, semua pekerjaan lokal diteruskan.
Remote diperiksa kembali setelah commit baru dan tetap 502ec4c. **Tidak mengklaim GitHub sudah diperbarui.**

Bundle baru mencakup rantai 6064027 → 9c105ee → c8301ad → 62e9357, dengan basis wajib 502ec4c.
Ukuran bundle **145.716 byte**, patch **662.500 byte**, backend ZIP **49.735 byte**. Bundle verify dan
Git fsck lulus. Gunakan bundle ATAU patch, bukan keduanya. Checkout audit bersih pada
`/home/user/.cache/eq-wa`; 156 berkas tracked cocok dengan source aktif `/home/user/english-quest`.
Direktori cache tidak diandalkan untuk persistensi; unduh bundle dan APK sebagai salinan mandiri.

## B. File yang diubah dan pemulihan source

Pada awal sesi, backend dan source web manual masih ada, tetapi salinan Android kembali stale:
**7 file berbeda, 2 overlay debug hilang**. Beberapa bukti uji historis juga hilang. Yang berbeda
dicadangkan ke `sebelum-pemulihan/` sebelum dipulihkan dari commit c8301ad yang tervalidasi. Tidak
menimpa source secara membabi buta atau mengulang implementasi manual dari nol.

Perubahan inti pada commit baru:
- `app.js`: Premium DANA–WhatsApp, informasi publik sebelum login, salin, link/pesan WhatsApp;
  renderer checkout dan pengambilan token otomatis dihapus.
- `access-client.js`: hanya API konfigurasi pembayaran untuk UI pembeli; wrapper checkout/order/claim
  otomatis dan pembuatan order buyer dibuang.
- `backend/manual_payments.py`: konfigurasi WhatsApp/normalisasi, dan pencatatan pembayaran oleh
  admin menggunakan transaksi/audit lama. Rule verifikasi dipakai bersama, bukan dilemahkan.
- `backend/server.py`: endpoint admin `/api/admin/manual-payments/record` dengan auth/rate limit.
- `backend/admin.html`: form pencatatan dari WhatsApp, token tetap diterbitkan terpisah; bootstrap
  HTTP loopback admin diperbaiki agar login lokal benar-benar bekerja.
- `MainActivity.java`: allowlist HTTPS `wa.me` yang ketat, tanpa mengganti identitas aplikasi.
- Aset Android disinkronkan, service worker v21.
- `deploy/env.produksi.example`, dokumentasi, helper backend lokal, verifier APK, dan tes.

Commit: **34 berkas, 1.373 baris ditambah / 393 dihapus**. Penghapusan baris terutama UI checkout
lama dan assertion produk lama yang memang diganti. Tidak ada tabel, DB, riwayat token, materi,
identitas aplikasi atau file APK rilis yang dihapus. Daftar lengkap: `DAFTAR-PERUBAHAN.txt`.

## C. Status tampilan pembayaran manual

Halaman kini menampilkan:
- **ENGLISH QUEST PREMIUM**, **Rp5.000**, satu kali bayar, permanen sesudah aktivasi sah, tanpa langganan.
- Nomor DANA dan nama penerima dari server; **SALIN NOMOR DANA**.
- Nomor WhatsApp dari server; **HUBUNGI ADMIN VIA WHATSAPP**.
- Tujuh petunjuk transfer → periksa penerima → WhatsApp → screenshot → tunggu pemeriksaan → token → aktivasi.
- Peringatan bahwa screenshot dan klik WhatsApp bukan bukti dana masuk atau pembayaran berhasil.

Tautan: `https://wa.me/<digit-internasional>?text=<pesan-terenkode>`. Draft:

> Halo Admin English Quest, saya ingin membeli Premium seharga Rp5.000. Saya akan mengirimkan bukti pembayaran setelah transfer.

Pesan tidak dikirim otomatis. Tidak ada email/password/token yang ditambahkan diam-diam. Nomor
WhatsApp lokal Indonesia, +kode negara, dan 00 internasional dinormalisasi; pemisah dibersihkan,
injeksi URL/karakter dan panjang tidak valid ditolak. Android sebelumnya hanya mengizinkan link
Wikipedia/Creative Commons; sekarang host `wa.me` yang tepat juga diizinkan. Domain tiruan dan port/
userinfo asing tidak ikut diizinkan.

Pembeli tidak perlu membuat pending order di aplikasi. Halaman tidak menghubungi checkout,
webhook, API order/claim token atau aktivasi hanya karena dibuka/WhatsApp ditekan. Kontak dapat
terlihat sebelum login bila server terkonfigurasi; aktivasi tetap membutuhkan akun permanen.

## D. Status konfigurasi

**Ketiga nilai masih kosong**, sesuai belum adanya data pemilik:

```dotenv
EQ_DANA_MANUAL_NUMBER=
EQ_DANA_MANUAL_NAME=
EQ_WHATSAPP_ADMIN_NUMBER=
```

Nantinya diisi pada environment backend sesuai `deploy/env.produksi.example`, bukan menaruh
credential admin/secret ke APK. API publik hanya membagikan kontak yang memang dibutuhkan pembeli.
Semua tiga nilai harus valid; jika ada yang kosong/invalid, kontak disembunyikan, tombol dinonaktifkan,
dan muncul pesan informasi pembayaran belum dikonfigurasi. Tidak ada nomor/nama palsu.

Validasi format tidak membuktikan kepemilikan akun atau keberadaan DANA/WhatsApp. Pemilik harus
memeriksa kontak sebelum digunakan. Helper backend lokal sengaja mengosongkan semua kontak dan
mengabaikan konfigurasi produksi, sehingga pengujian awal aman tanpa transaksi nyata.

## E. Status token dan admin

Alur admin sekarang:
1. Pembeli menyampaikan email akun English Quest dan screenshot melalui WhatsApp.
2. Admin memeriksa transaksi pada DANA penerima, termasuk nominal Rp5.000 dan referensi, bukan hanya gambar.
3. Form **Pembayaran dari WhatsApp** menerima email akun, nominal, referensi dan konfirmasi pemeriksaan.
4. Endpoint admin `record` mencatat pembayaran verified dalam transaksi atomik. **Belum menerbitkan token.**
5. Admin menekan **Terbitkan satu token**, menyalin kode yang tampil sekali, lalu mengirimnya manual via WhatsApp.
6. Pembeli memasukkan kode; backend memvalidasi token dan status Premium.

Sistem order/audit tetap digunakan sebagai catatan internal admin. Tidak ada migrasi schema baru pada
sesi ini; tabel/migrasi aditif sebelumnya tetap dipertahankan. Pending lama masih dapat dikelola.
Role admin diperiksa di backend/dalam transaksi; biasa, self-review, akun pembeli tidak dikenal,
nominal salah, receipt duplikat dan konfirmasi yang tidak ada ditolak. Kegagalan rollback tidak
meninggalkan order baru atau Premium.

Satu order/satu token; enam pencatatan bersamaan tetap satu catatan. Token disimpan sebagai hash/HMAC,
terikat pemilik order sebelum klaim, dan ditolak untuk akun lain. Aktivasi ulang pemilik hanya
idempoten, bukan klaim akun kedua. Premium tidak memiliki expiry dan bertahan setelah logout/login,
restart dan backup/restore selama DB/pepper tetap benar; akses tetap harus diverifikasi server.

**Batas penting:** kode hanya tampil sekali. Jika kode/respons penerbitan hilang, hash DB tidak bisa
mengembalikan kode dan retry tidak membuat token pengganti. Prosedur dukungan/refund harus ditetapkan
pemilik sebelum melayani pembeli.

Kode backend otomatis lama tidak dibuang agar data/regresi lama tetap aman. HTTP otomatis produksi
sudah diblokir; hanya mode tes loopback eksplisit yang mempertahankan jalur legacy. Klien baru tidak
mengekspor wrapper atau memanggilnya. Ini **bukan integrasi pembayaran otomatis yang berhasil**.

## F. Hasil pengujian

| Pengujian akhir | Hasil |
|---|---|
| Seluruh unittest Python | **120 lulus, 0 gagal, 0 skipped** (32,000 detik) |
| Tambahan Python sesi ini | 14 tes konfigurasi/normalisasi, record admin, concurrency, HTTP dan login admin lokal |
| Node registrasi/login | 13 kelompok lulus |
| Node failure paths | 8 kelompok lulus |
| Node gates | 11 kelompok + 43 renderer lulus |
| Node DANA–WhatsApp | 11 kelompok lulus |
| Total kelompok Node | **43** |
| Aset root ↔ Android ↔ isi APK | **17 identik**, cache v21 |
| Sintaks Python/JS admin/klien | Lulus |
| ZIP backend | Integritas dan 10 berkas cocok dengan source |
| Git bundle/fsck/diff check | Lulus |
| APK | Manifest, signature, bridge, link WhatsApp, aset dan hash Vosk lulus |

Bukti utama: `evidence/dana-whatsapp/final-pipeline.txt` dalam commit/bundle. File run antara
`python.txt` memiliki 119; setelah tes login admin nyata ditambahkan, run **akhir 120**. Tidak
menjumlahkan run berulang sebagai jumlah tes unik.

Cakupan mencakup harga/kontak/copy/URL/prefill, no checkout, no token dari WhatsApp/screenshot,
invalid/used token, permanensi/logout/relogin, admin unauthorized, receipt/nominal, ownership,
backup/migrasi dan quota lima Easy. TLS lokal nyata dan backend SQLite ada pada suite lama yang
ikut dijalankan. Login admin HTTP loopback menggunakan access-client asli terhadap server nyata.

Tes UI checkout lama memang perlu disesuaikan karena produknya dihapus: kini menguji bahwa fungsi
checkout tidak pernah dipanggil, bahkan jika API lama tersedia. Tes config lengkap diberi field WA
baru. Tes aktivasi/auth/database lama tidak dilemahkan. Fixture tes sintetis tidak dipakai untuk
pembayaran pelanggan, tidak menghubungi DANA, dan tidak mengirim WhatsApp.

**Kegagalan awal yang diperbaiki:** satu expected fixture normalisasi salah menghitung digit; harness
UI masih merujuk fungsi checkout yang sudah dihapus dan properti window yang tidak diekspor. Referensi/
fixture diperbaiki, lalu seluruh pipeline diulang sampai lulus. Tidak ada kegagalan pada hasil akhir.
Peringatan build API Android deprecated dan library native tidak di-strip tetap dicatat; library
utuh dipaketkan, fitur tidak dihapus. Belum ada uji HP atau pesan WhatsApp sungguhan.

## G. APK debug baru

| Atribut | Hasil |
|---|---|
| Build | **BUILD SUCCESSFUL**, 1 menit 24 detik, 35 tugas executed |
| APK yang sekarang tersedia | `/home/user/artefak-apk/English-Quest-1.7.1-dana-whatsapp-localtest-debug.apk` |
| Ukuran | **84.920.526 byte**, sekitar 80,99 MiB |
| applicationId | **`com.englishquest.app.debug`** |
| Identitas dasar | `com.englishquest.app`, suffix debug yang sudah ada |
| versionName / versionCode | **`1.7.1-debug` / `13`**, tidak dinaikkan |
| Android | minSdk 23, target/compileSdk 35 |
| API origin debug | `http://127.0.0.1:8088`, HTTP dev hanya lokal |
| Toolchain build | JDK 17.0.20.1, Gradle 8.9, AGP 8.7.3 |

SHA-256:

```text
af7f5fc21c57c6fb59b552b3cf2768e61173d6e69057936c3aa0d5f1bede7280
```

Ini APK build baru, bukan APK lama yang diganti nama. Signature valid dan sama dengan APK uji lokal
sebelumnya. APK historis root memakai signer berbeda; Android bisa menolak update di atasnya.
Jangan uninstall/clear data atau mengganti package untuk menghindari konflik tanpa backup/persetujuan.

Hasil asli Gradle berada di `english-quest-android/app/build/outputs/apk/debug/app-debug.apk` saat
build. Setelah disalin dan diverifikasi hash, **folder build itu dibersihkan** sesuai permintaan.
Lokasi unduhan pada tabel tetap ada. APK rilis/lama tidak ditimpa. Tidak ada secret produksi,
DB, private key atau pola PAT/token plaintext yang terdeteksi di APK; pemindaian pola bukan audit
rahasia menyeluruh. Kunci debug yang sudah ada dipakai, bukan membuat kunci signing pemilik baru.

### Pembersihan workspace

- Awal: cache metadata SDK sekitar 6 MB dan tiga skrip edit sementara yang sudah diterapkan dihapus.
- Akhir: **1.671 GiB** berkas toolchain/cache/intermediate Gradle dan bytecode sementara dibersihkan,
  setelah APK, ZIP, commit dan bundle tervalidasi.
- Source aktif, checkout audit, database/data pengguna, debug keystore, APK lama/baru, bundle,
  backup pemulihan dan laporan **tidak dihapus**.
- Daftar rinci: `PEMBERSIHAN.txt` dan `PEMBERSIHAN-AKHIR.txt`. Ini ruang sandbox, bukan verifikasi
  kuota akun Arena. Rebuild berikutnya perlu menyediakan kembali toolchain yang telah dibersihkan.

## H. Tindakan pemilik yang masih diperlukan

1. Simpan APK, checksum dan bundle di perangkat sendiri.
2. Isi nomor DANA, nama penerima dan WhatsApp yang sah pada backend bila siap menguji kontak nyata.
3. Selesaikan autentikasi GitHub langsung pada perangkat sendiri untuk push audit; jangan mengirim
   PAT/password ke chat. PAT yang pernah terpapar tetap perlu dicabut.
4. Lakukan checklist HP dan tentukan pilihan aman jika signer APK terpasang berbeda.
5. Tentukan kebijakan kode hilang/refund dan kanal operasional admin sebelum menerima uang.
6. Hosting/HTTPS/persistent DB/backup dan deployment masih memerlukan keputusan/persetujuan terpisah.
   Anggaran nol tetap dihormati; tidak membeli atau mengaktifkan layanan.

Push dapat dilanjutkan dari clone bersih yang memuat 502ec4c:

```sh
git switch audit-baseline-1.7.1
git bundle verify /path/ke/English-Quest-62e9357.bundle
git fetch /path/ke/English-Quest-62e9357.bundle refs/heads/audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
# Setelah login browser langsung di perangkat pemilik:
git push origin audit-baseline-1.7.1
```

Ganti path nyata; hentikan bila working tree berisi perubahan atau fast-forward gagal. Jangan force
push, reset atau mengubah main. Perintah ini petunjuk pemilik, bukan klaim push sudah dilakukan.

## I. Langkah berikutnya untuk HP

Lihat **PANDUAN-HP.md** untuk langkah lengkap. Instal APK dengan signer sesuai, lalu:
1. Tanpa server: cek demo terbatas, harga, pesan belum dikonfigurasi dan gagal koneksi tanpa Premium.
2. Ekstrak backend ZIP ke folder baru Termux; jalankan `python3 tools/backend-lokal-manual.py serve`.
3. Cek `/api/health`, daftar/login/logout/restart melalui APK; state DB/pepper lokal dipertahankan.
4. Admin dapat dibuat di terminal oleh pemilik, bukan memakai akun bawaan. Login panel lokal sudah
   diuji terhadap server nyata, tetapi operasi Termux pada HP belum diuji langsung.
5. Konfigurasi kontak kosong secara default: tombol harus nonaktif. Setelah kontak sah diisi pada
   backend normal, periksa salin nomor dan draft WhatsApp tanpa melakukan transfer nyata.
6. Jangan menganggap screenshot/klik WhatsApp sebagai pembayaran atau memberi token tes pada data nyata.

**Sudah diterapkan:** DANA–WhatsApp, mekanisme admin aman, native link dan APK. **Sudah diuji lokal:**
suite/backend/TLS/client/admin/APK statis. **Belum diuji di HP:** instalasi, pembukaan WhatsApp,
perilaku WebView, mikrofon/ASR/TTS. **Belum dilakukan:** push, hosting/deployment publik, pengiriman
rilis kepada pengguna dan transaksi nyata. Tidak ada klaim siap produksi.
