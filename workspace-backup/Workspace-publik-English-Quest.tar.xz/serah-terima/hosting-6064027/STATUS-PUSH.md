# Status push dan cara menyelesaikannya

**GitHub BELUM terbarui.** Izin pengguna untuk push sudah ada, tetapi autentikasi tidak tersedia.

- Remote audit: `502ec4c59d1d59cb19c29b8ff528e07412f53252`.
- Commit lokal siap: `606402771d73f5c5519c8c3965f4b1431a31596e`.
- Branch lokal/tujuan: `audit-baseline-1.7.1`.
- Commit: `Prepare audited HTTPS deployment, hosting options and safe database backups`.
- Percobaan push: exit 128, `could not read Username for 'https://github': terminal prompts disabled`.
- Remote diverifikasi sesudah percobaan: tetap `502ec4c`; `main` tetap `d05e4e6`.
- 33 file berubah/ditambahkan; tidak ada APK, DB, rahasia atau GitHub workflow deployment baru.
- Bundle incremental diverifikasi dengan `git bundle verify`; membutuhkan basis `502ec4c`.

## Cara push dari komputer pemilik yang terautentikasi

Jangan masukkan token ke URL remote atau percakapan. Gunakan login browser melalui Git Credential
Manager/GitHub CLI atau SSH key milik sendiri pada komputer Anda. Jangan mengaktifkan hosting
atau workflow deployment otomatis saat langkah ini.

1. Unduh `English-Quest-6064027.bundle` dan `.sha256` ke folder yang sama.
2. Verifikasi checksum file menggunakan utilitas SHA-256 di komputer Anda.
3. Dari folder kerja baru, jalankan:

```sh
git clone --branch audit-baseline-1.7.1 https://github.com/bloxfruit6571-design/English-apk.git
cd English-apk
git status --short
git bundle verify /PATH/English-Quest-6064027.bundle
git fetch /PATH/English-Quest-6064027.bundle refs/heads/audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
git log -1 --oneline
# Harus 6064027, dan tidak ada perubahan lokal lain yang belum ditinjau.
git push origin HEAD:refs/heads/audit-baseline-1.7.1
git ls-remote origin refs/heads/audit-baseline-1.7.1
```

Ganti `/PATH/` dengan lokasi unduhan, bukan URL. Jika fast-forward atau push ditolak karena remote
sudah berubah, **berhenti; jangan force-push**. Perlu audit/rekonsiliasi ulang dengan perubahan baru.
Bila memakai clone yang sudah ada, jangan melakukan merge sebelum perubahan lokal diamankan.

Hash remote yang diharapkan setelah push ini adalah `606402771d73f5c5519c8c3965f4b1431a31596e`.
Setelah Anda menjalankan push, saya dapat memeriksa remote publik tanpa meminta password.

## Isi paket

- `English-Quest-6064027.bundle`: commit Git incremental, mempertahankan ID commit.
- `English-Quest-6064027.patch`: alternatif format-patch; jangan terapkan sekaligus dengan bundle.
- `English-Quest-source-6064027.tar.gz`: source pada commit, tanpa APK biner lama dan tanpa `.git`.
- `LAPORAN-HOSTING-PREMIUM.md`: laporan A–L.
- `PILIHAN-HOSTING.md`: biaya/batas/sumber resmi dan keputusan yang diperlukan.

Berkas dalam paket ini adalah versi terbaru; paket `502ec4c` sebelumnya hanya riwayat.
Tidak ada deployment publik, APK online baru, atau transaksi DANA yang dilakukan.
