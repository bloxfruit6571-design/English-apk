# Anggaran nol + push GitHub dari HP Android

Pilihan Anda: **tidak mengaktifkan hosting berbayar**, memakai **HP Android**.
Belum ada layanan hosting yang dibuat. Pendaftaran online dan DANA belum siap.

## 1. Keputusan hosting

Tidak membeli domain, tidak memasukkan kartu pembayaran, tidak mengaktifkan upgrade otomatis,
dan tidak membuat akun/layanan tanpa persetujuan. Kita tidak memakai filesystem sementara
untuk akun pengguna nyata. Dokumentasi pilihan gratis ada pada `PILIHAN-HOSTING.md`.

Anggaran nol belum menentukan penyedia. Railway trial/Free terbatas kredit dan retensi;
PythonAnywhere gratis butuh adaptasi WSGI; Render Free tidak punya disk persisten untuk SQLite.
Tidak ada perubahan arsitektur atau migrasi database dilakukan untuk memaksakan hosting gratis.
Tahap aman sekarang: simpan perubahan ke GitHub dahulu, kemudian putuskan pilot gratis terbatas
beserta batas data dan rencana backup—bukan langsung membuka pendaftaran pelanggan.

## 2. Siapkan Termux (di HP Anda, bukan di sandbox)

Gunakan Termux melalui F-Droid resmi: https://f-droid.org/en/packages/com.termux/ .
Versi yang direkomendasikan di halaman ini membutuhkan Android 7 atau lebih baru.
Jika sudah ada Termux, jangan uninstall/data-clear tanpa backup hanya untuk mengikuti panduan.

Buka Termux, lalu jalankan:

```sh
pkg update
pkg install git gh coreutils
termux-setup-storage
```

Izinkan akses penyimpanan jika Anda setuju; ini dipakai membaca berkas bundle dari Downloads.
Paket `gh` tersedia pada repo Termux resmi:
https://raw.githubusercontent.com/termux/termux-packages/master/packages/gh/build.sh .

## 3. Unduh dua berkas publik dari hasil sesi ini

- `English-Quest-6064027.bundle`
- `English-Quest-6064027.bundle.sha256`

Simpan keduanya di folder **Download** HP. Pastikan nama tidak berubah menjadi `(1)` dan bukan
halaman HTML yang tersimpan. Bundle sekitar 61 KB, berisi commit, bukan password/token.

Di Termux:

```sh
cd ~/storage/downloads
sha256sum -c English-Quest-6064027.bundle.sha256
```

Harus tampil `OK`. SHA-256 bundle:
`d5092c6ad33a16e2fae1313d7cc9573d0655f2954cc6c2cde49cf87c7fcbd160`.
Jika berbeda, berhenti dan unduh ulang; jangan teruskan.

## 4. Login langsung ke GitHub

```sh
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
```

Ikuti browser untuk login ke akun yang memiliki hak tulis pada `bloxfruit6571-design/English-apk`.
Kode login hanya dimasukkan di halaman GitHub resmi yang ditunjukkan CLI. **Jangan kirim kode,
password, token, file konfigurasi `gh`, atau tangkapan layar autentikasi kepada saya.**
Periksa permintaan izin OAuth sebelum menyetujuinya.

GitHub CLI memakai credential store bila tersedia; jika tidak, token dapat disimpan sebagai
file plaintext dalam direktori konfigurasi privat aplikasi. Jangan salin folder konfigurasi
Termux/gh ke Downloads, GitHub atau backup publik. Jangan gunakan `--insecure-storage`.
Dokumentasi: https://cli.github.com/manual/gh_auth_login .

## 5. Masukkan commit dan push hanya branch audit

Cara yang mudah dipahami (clone biasa bisa mengunduh sekitar 100 MB termasuk APK lama):

```sh
cd ~
git clone --branch audit-baseline-1.7.1 --single-branch \
  https://github.com/bloxfruit6571-design/English-apk.git eq-push-6064027
cd eq-push-6064027
git bundle verify ~/storage/downloads/English-Quest-6064027.bundle
git fetch ~/storage/downloads/English-Quest-6064027.bundle refs/heads/audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
git log -1 --oneline
```

Jalankan perintah satu per satu. Jika folder sudah ada, jangan hapus/menimpanya; gunakan nama
folder baru. Jika ada error, berhenti. Commit yang diharapkan adalah `6064027`.

Push setelah hasil tersebut benar:

```sh
git push origin HEAD:refs/heads/audit-baseline-1.7.1
git ls-remote origin refs/heads/audit-baseline-1.7.1
```

Harus menghasilkan:

```text
606402771d73f5c5519c8c3965f4b1431a31596e  refs/heads/audit-baseline-1.7.1
```

Jangan memakai `--force`. Bila remote sudah berubah, fast-forward/merge ditolak atau muncul
403, berhenti; perlu pemeriksaan akses/perubahan remote. Jangan push `main` atau membuat release.
Repo ini tidak ditambahkan workflow deployment; jangan sambungkan auto-deploy hosting saat push.

Sesudah berhasil, beri tahu saya **“sudah push”**. Saya dapat memeriksa hash remote publik sendiri,
tanpa meminta rahasia. GitHub baru disebut terbarui setelah pemeriksaan tersebut cocok.

## 6. Sesudah selesai

Jika tidak ingin sesi login tersimpan di Termux, jalankan `gh auth logout --hostname github.com`.
Logout lokal tidak selalu mencabut otorisasi di server; bila diperlukan, cabut akses GitHub CLI
di Settings → Applications pada akun GitHub. Jangan membagikan direktori kredensial.

Panduan ini belum dijalankan di HP Anda; tidak ada klaim push/tes Android berhasil.
