# Melanjutkan push audit dari HP sendiri

Push di workspace gagal karena tidak tersedia autentikasi Git yang aman (`could not read Username`, exit 128). Tidak ada data terunggah. Jangan kirim PAT, password, OTP atau device code melalui chat. Jika token pernah terekspos, cabut melalui pengaturan akun; jangan digunakan kembali.

## Cakupan yang aman

Commit baru **97100ce146e18b75853cd137d9de9648def64cd1** pada **audit-baseline-1.7.1**, parent **62e9357**. Bundle menyertakan rangkaian commit lokal sejak baseline remote **502ec4c59d1d59cb19c29b8ff528e07412f53252**. Bukan push ke main.

Source, test, dokumentasi dan bukti build aman dipulihkan melalui bundle. APK debug terbaru dan ZIP backend diberikan terpisah. Tidak memasukkan seluruh home directory: database pengguna, pepper, token, kredensial, debug/release signing key, unggahan privat, cache, SDK dan build sementara tidak boleh dipublikasikan. Nomor pemilik dalam JSON adalah informasi publik yang memang diizinkan tampil pada APK.

## Termux + autentikasi browser pada perangkat sendiri

Unduh `English-Quest-97100ce.bundle` ke Downloads. Gunakan folder clone baru agar tidak menimpa perubahan lokal:

```sh
pkg install git gh
termux-setup-storage
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
git clone --branch audit-baseline-1.7.1 https://github.com/bloxfruit6571-design/English-apk.git English-apk-owner-review
cd English-apk-owner-review
git bundle verify ~/storage/downloads/English-Quest-97100ce.bundle
git fetch ~/storage/downloads/English-Quest-97100ce.bundle audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
git status
git log -1 --oneline
```

Selesaikan login hanya di browser sendiri. CLI bisa menyimpan token plaintext bila credential store tidak tersedia; jangan membagikan folder konfigurasi CLI/Termux. Periksa commit dan diff dahulu. Jika merge gagal karena branch remote sudah maju/divergen, hentikan untuk review; jangan reset atau force-push.

Jika hasil review benar dan login berwenang:

```sh
git push origin HEAD:refs/heads/audit-baseline-1.7.1
```

Tidak ada perintah push main, force-push, deployment atau unggah release. Konfirmasi sukses dari hasil perintah dan commit pada GitHub; adanya bundle lokal bukan bukti push berhasil.

Fallback `English-Quest-502ec4c-ke-97100ce.patch` berisi diff biner dari baseline yang sama. Patch berhasil diterapkan pada index baseline dan menghasilkan tree yang sama dengan commit final. Bundle lebih disarankan karena mempertahankan riwayat commit. Peringatan trailing whitespace hanya berasal dari output Gradle asli dalam log, tidak menyebabkan patch gagal.
