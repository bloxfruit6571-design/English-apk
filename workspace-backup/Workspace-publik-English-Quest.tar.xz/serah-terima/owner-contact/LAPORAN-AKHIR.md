# English Quest — laporan akhir A–J

**Status: implementasi, tes lokal, APK debug baru dan paket pemulihan selesai. Push GitHub, uji HP nyata dan layanan publik belum selesai.** Tidak ada transfer DANA, pesan WhatsApp, deployment produksi atau upload release yang dilakukan.

## A. Branch dan commit aktual

- Branch audit lokal: **audit-baseline-1.7.1**.
- Commit baru: **97100ce146e18b75853cd137d9de9648def64cd1**.
- Parent yang diperiksa sebelum perubahan: **62e9357c95a04e8c0bcabaa4a8c5e0cec0721a6f**. Baseline remote audit terakhir diambil: **502ec4c59d1d59cb19c29b8ff528e07412f53252**. Bukan menganggap source masih sama dengan baseline remote.
- Checkout Git: `/home/user/.cache/eq-owner`; source aktif: `/home/user/english-quest`. **171 file tracked byte-identik**, checkout bersih. Source aktif tetap tanpa `.git`; bundle menyimpan riwayat audit untuk dipulihkan.
- **Push gagal**, exit 128 karena autentikasi aman tidak tersedia. Tidak diulang dengan keadaan autentikasi sama, tidak meminta/menggunakan token lewat chat. Tidak ada data yang berhasil diunggah; **main tidak disentuh**. `origin/main` tidak di-fetch pada clone audit single-branch; tidak mengarang pemeriksaan remote terbaru.
- Bundle 175.924 byte telah diverifikasi; patch 705.539 byte diterapkan pada index baseline dan menghasilkan tree final yang sama. `git fsck` lulus. Peringatan whitespace berasal dari log Gradle asli, bukan kegagalan patch.

## B. File yang diperiksa dan diubah

Diperiksa: source browser, backend konfigurasi/pembayaran/token/auth, panel admin, launcher lokal, project Android/native bridge, build config/manifest, tes, panduan, Git baseline dan APK sebelumnya. Perbedaan Android lama dicadangkan sebelum pemulihan awal; perubahan baru tidak ditimpa baseline.

Commit mencakup **37 file**; daftar lengkap: `DAFTAR-PERUBAHAN.txt`. Perubahan utama:

- Baru: `premium-contact.json`, salinan aset Android, `KONFIGURASI-PEMILIK-PREMIUM.md`, `PANDUAN-APK-KONTAK-PEMILIK.md`, tes Python/Node kontak pemilik, bukti final.
- Diubah: `app.js`, `access-client.js`, `sw.js` + salinan Android; `MainActivity.java`; `backend/manual_payments.py`, `backend/server.py`; launcher/verifier; template env dan dokumentasi terkait; tes/parity yang relevan.
- Panduan lama diberi label arsip agar instruksi kontak kosong tidak dianggap konfigurasi aktif. Identitas, versi, navigasi, konten belajar, arsitektur token dan database dipertahankan.

**Pembersihan selesai:** 2.053.782.599 byte logis (sekitar **1,913 GiB**) dari toolchain/cache/build/intermediate dan tiga APK debug hasil build lama yang digantikan. Hash APK lama diperiksa dahulu dan checksum historis diarsipkan. Source, DB pengguna, kunci signing, APK historis root repository, APK baru, bundle/patch dan laporan tetap disimpan; hash file terlindungi tidak berubah. Ini jumlah ukuran file, bukan pengukuran blok disk unik. Detail: `PEMBERSIHAN-AKHIR.txt`.

## C. Tampilan DANA

- Judul **ENGLISH QUEST PREMIUM**.
- **Harga: Rp5.000,00**; sekali bayar, Premium permanen sesudah aktivasi sah, tanpa langganan.
- DANA: **0856-5670-6104**.
- Nama penerima: **belum dikonfirmasi**, tidak direka/tidak dinyatakan terverifikasi.
- Delapan petunjuk pembeli tersedia, termasuk memeriksa nomor penerima sebelum membayar dan menunggu pemeriksaan transaksi DANA langsung.
- JSON publik benar-benar dibundel ke APK. Kontak dapat terlihat saat backend gagal dijangkau, dengan keterangan sumber APK; ini **bukan bukti server/aktivasi siap**. Respons server berhasil, termasuk penonaktifan kontak, mengungguli fallback. File hilang/rusak tidak menghasilkan nomor palsu.

## D. Salin nomor DANA

**SALIN NOMOR DANA** menyalin **085656706104**—nomor yang sama tanpa pemisah. Android memakai ClipboardManager melalui bridge, dengan fallback browser/textarea. Hanya setelah jalur copy menyatakan sukses muncul **“Nomor DANA berhasil disalin”**; jika gagal seluruhnya, muncul petunjuk salin manual.

Tidak mencatat pembayaran atau memberikan Premium. Jalur native/browser/gagal diuji dengan stub; bridge terdeteksi dalam DEX APK. **Clipboard HP nyata belum diuji.**

## E. WhatsApp

- Tampilan: **0856-5670-6104**.
- Tombol: **KONFIRMASI PEMBAYARAN VIA WHATSAPP**.
- Tujuan: `https://wa.me/6285656706104?text=…`, menggunakan URL encoding dan allowlist HTTPS host/path yang tepat.
- Draft final:

```text
Halo Admin English Quest.

Saya ingin membeli Premium seharga Rp5.000.

Saya sudah melakukan pembayaran melalui DANA.
Berikut saya kirimkan screenshot bukti transfer untuk diperiksa.

Mohon verifikasi pembayaran saya dan berikan token Premium
jika pembayaran sudah benar-benar diterima.

Terima kasih.
```

Draft dapat ditinjau/diedit. Pernyataan “sudah melakukan pembayaran” hanya dipakai setelah transfer sungguhan. Tidak ada pesan/screenshot dikirim otomatis; membuka WhatsApp tidak memberi Premium. URL/draft diuji lokal, **WhatsApp asli belum dibuka/diuji di HP**.

## F. Aktivasi dan keamanan

Alur tetap: pembeli transfer → kirim screenshot/identitas akun → admin cek **riwayat DANA langsung** → catat penerimaan yang benar → admin berwenang menerbitkan satu token secara terpisah → kirim manual → pembeli memasukkan token → backend memvalidasi.

Screenshot bukan bukti final. Tidak ada checkout otomatis pada UI pembeli, merchant API/webhook produksi, auto-detect dana, auto-issuance atau flag Premium lokal. Backend/history legacy tidak dibongkar.

Token terikat satu akun, hanya hash/HMAC disimpan, kode salah/akun lain ditolak, satu order tidak menghasilkan token berulang. Pemilik melakukan retry secara idempoten; Premium permanen bertahan setelah logout/login/reopen DB selama DB/pepper dipertahankan. Pengguna biasa tidak boleh menerbitkan. Kode plaintext tampil sekali dan tidak dapat dipulihkan dari hash. Tes menggunakan fixture terisolasi, bukan uang pelanggan.

## G. Pengujian yang benar-benar dijalankan

| Pemeriksaan final | Hasil |
|---|---|
| Python seluruh unittest | **126 lulus**, 31.508 detik |
| Node seluruh suite | **53 kelompok lulus** |
| Renderer rute | **43** smoke-tested |
| Parity root–Android | **18 aset identik**, SW v22 |
| Gradle APK final | **BUILD SUCCESSFUL**, 35 task (4 executed, 31 up-to-date), 13 detik |
| APK aktual | Nomor/harga/nama/draft/aset/DEX/model/signature/package/versi diperiksa; **PASS** |
| Paket backend ZIP | 11 file CRC/parity lulus; server dari ZIP melayani health/config/JSON/admin/client HTTP 200; tidak ada akun/order/token tercipta |
| Recovery Git | Bundle valid, patch menghasilkan tree final, fsck dan 171-file parity lulus |

Pemetaan 14 persyaratan ada di `english-quest/evidence/owner-contact/CATATAN-TES.md`. Log final: `final-pipeline.txt`; log Python/Node lainnya adalah run sebelumnya. APK tidak berisi berkas DB/env/private key/keystore atau pola kredensial/token yang diperiksa. **Pemindaian pola bukan audit secret menyeluruh.**

Belum dilakukan: instalasi/update HP, clipboard Android fisik, intent WhatsApp nyata, mikrofon/ASR/TTS HP, transaksi DANA, verifikasi identitas penerima, registrasi/aktivasi HTTPS publik. Tidak ada klaim lulus untuk hal-hal tersebut.

## H. APK debug baru

**File:** `/home/user/artefak-apk/English-Quest-1.7.1-owner-contact-localtest-debug.apk`

| Metadata | Nilai |
|---|---|
| Ukuran | **84.929.134 byte** (sekitar 80,99 MiB) |
| applicationId | **com.englishquest.app.debug** |
| versionName / versionCode | **1.7.1-debug / 13**, tidak dinaikkan |
| minSdk / targetSdk | **23 / 35** |
| API debug | **http://127.0.0.1:8088**, loopback-only |
| Signer | Sama dengan debug lokal register/manual/WhatsApp sebelumnya; berbeda dari APK historis root |

**SHA-256:**

```text
372b126c4bd22c6665c7c5bd7aab741ab0194f213ed8a987024ba12d5f193a58
```

Checksum diverifikasi ulang setelah cleanup. APK ini bukan file lama yang diganti nama: source/kontak/draft dibaca dari arsip APK final. Bukan APK produksi dan bukan layanan online-ready. Tidak mengganti atau mengunggah release, tidak membuat key baru. Jika signer instalasi lama berbeda, jangan uninstall/clear data tanpa backup dan keputusan pemilik.

## I. Tindakan pemilik

1. Unduh APK baru, checksum, `PANDUAN-HP.md`, backend ZIP serta bundle/patch. Simpan salinan sendiri; jangan mengandalkan workspace sebagai satu-satunya backup.
2. Konfirmasikan nama penerima dan kepemilikan akun langsung di DANA/WhatsApp. Nomor sudah sesuai instruksi pemilik; keberadaan akun tidak diverifikasi oleh tes format.
3. Uji APK/Termux mengikuti panduan. Backend paket ini lokal di HP yang sama, bukan backend bersama untuk pelanggan di HP berbeda. Token dari DB operator tidak otomatis berlaku pada DB lokal lain.
4. **Jangan menerima pembayaran pelanggan sebelum layanan akun/aktivasi bersama dan penyimpanan/backup permanen siap.** Backend HTTPS publik belum dipilih/disiapkan; tidak ada hosting/domain berbayar atau deployment yang dipesan.
5. Untuk push, autentikasi sendiri di browser perangkat melalui panduan `PUSH-DARI-HP.md`, review bundle, lalu push hanya audit. Jangan kirim kredensial ke chat. Source aman saja, bukan database/kunci/seluruh folder pribadi.

## J. Pengujian berikutnya

Prioritas: instalasi aman → demo 5 Easy → tampilan angka/nama/harga → copy dan tujuan/draft WhatsApp tanpa mengirim → daftar/login lokal → validasi token pada fixture terisolasi → logout/relogin/restart → penolakan pengguna biasa/akun lain. Checklist rinci tersedia pada panduan HP.

Setelah pemilik memilih dan menyetujui backend HTTPS dengan data persisten/backup, lakukan uji registrasi/aktivasi publik dari HP sebelum menyebut aplikasi siap jual. Pembayaran sungguhan hanya dengan keputusan pemilik; screenshot tidak menggantikan pemeriksaan dana masuk.

**Berkas serah-terima:** APK + `.sha256` di `artefak-apk`; panduan, backend ZIP, bundle, patch, daftar perubahan, status/verifikasi Git, checksum paket dan catatan cleanup di `serah-terima/owner-contact`. Tidak ada data berhasil dipush pada pengerjaan ini.
