# Push dahulu; hapus hanya setelah salinan GitHub terverifikasi

## Status

Push dari workspace gagal: tidak tersedia autentikasi GitHub, exit 128. Konektor GitHub pada sesi ini tidak didukung. Tidak ada upload berhasil. Branch audit remote masih 502ec4c; commit source lokal 97100ce disimpan di bundle. Main tidak disentuh.

APK debug historis sudah tersedia di GitHub. Sebelum menghapus salinan lokal, seluruh 85.079.299 byte diunduh kembali lewat HTTPS dan SHA-256 dicocokkan. APK baru 84.929.134 byte **belum ada di GitHub dan tidak dihapus**. Karena APK baru sendiri lebih besar daripada 70 MB, batas itu belum dapat dicapai tanpa salinan aman terlebih dahulu.

## File yang perlu diunduh ke Downloads HP

1. `English-Quest-1.7.1-owner-contact-localtest-debug.apk` dari folder `artefak-apk`.
2. `English-Quest-97100ce.bundle` dari `serah-terima/owner-contact`.
3. `Workspace-publik-English-Quest.tar.xz` dari folder panduan ini.
4. `SHA256SUMS-PUSH.txt` dari folder panduan ini.
5. `push-workspace-dari-hp.sh` dari folder `tools`.

Gunakan nama file persis; jangan memakai file APK lama atau file download yang belum selesai.

## Jalankan di Termux resmi pada HP pemilik

```sh
termux-setup-storage
bash ~/storage/downloads/push-workspace-dari-hp.sh
```

Skrip memasang git/gh/python/coreutils, memeriksa checksum, lalu membuka alur login browser GitHub pada perangkat sendiri. **Jangan kirim password, PAT, OTP atau device code ke chat.** CLI dapat memakai penyimpanan token plaintext bila credential store tidak tersedia; jangan bagikan konfigurasi Termux. Login di HP tidak otomatis mengautentikasi workspace Arena.

Skrip membuat clone baru, memulihkan commit source dari bundle, menambahkan APK baru dan arsip workspace publik, lalu push **hanya audit-baseline-1.7.1**. Tidak ada force-push, reset, push main, unggah release, deployment atau penghapusan file. Akun GitHub harus punya izin tulis repository. GitHub mungkin memberi peringatan ukuran APK di atas 50 MB, tetapi file ini masih di bawah batas per-file Git 100 MiB; koneksi/data unduhan dan unggahan tetap diperlukan.

Setelah push, skrip memeriksa commit remote dan **mengunduh ulang APK baru, APK historis, serta arsip publik** sambil mencocokkan SHA-256. Jika terjadi error, berhenti; tidak menganggap upload berhasil atau menghapus file. Pemeriksaan ini juga membutuhkan data internet.

Kirim hanya commit hasil akhir atau pesan **SUDAH**. Asisten kemudian dapat memeriksa GitHub secara independen sebelum menghapus salinan lokal APK baru dan arsip sementara, sehingga workspace bisa turun di bawah 70 MB.

## Cakupan arsip publik

Arsip menyimpan source, aset, test, dokumen, bukti, patch/bundle, arsip proyek terdahulu dan helper yang berada pada lokasi proyek publik workspace. Daftar path/ukuran/checksum ada di `MANIFEST-WORKSPACE-PUBLIK.json` dalam arsip dan di folder ini. APK baru dikirim terpisah agar tidak digandakan dalam arsip. APK historis sudah ada dalam repository.

**Tidak diunggah:** kunci signing/debug/ADB, database/state pengguna, credential, direktori tersembunyi pribadi/cache, dan unggahan privat. Semua ini bukan sampah dan bukan bahan publikasi. Nomor DANA/WhatsApp pemilik adalah konfigurasi publik yang memang diizinkan pada APK. Pemindaian pola/arsip bukan jaminan audit rahasia menyeluruh.

Arsip upload merupakan file sementara untuk proses backup ini, bukan tanda batas 70 MB sudah tercapai. Jangan menghapusnya atau APK sebelum verifikasi remote sukses. Source dan private key tetap dilindungi setelah pembersihan.
