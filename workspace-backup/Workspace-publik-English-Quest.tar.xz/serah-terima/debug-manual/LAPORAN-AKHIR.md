# English Quest — pembayaran manual dan APK debug

**18 Oktober 2026 · Pekerjaan lokal selesai · Belum online / belum push**

## Unduhan utama

- [APK debug pembayaran manual](../../artefak-apk/English-Quest-1.7.1-dana-manual-localtest-debug.apk)
- [Checksum APK](../../artefak-apk/English-Quest-1.7.1-dana-manual-localtest-debug.apk.sha256)
- [Panduan uji HP / Termux](PANDUAN-HP.md)
- [Backend lokal kecil, tanpa akun/DB/secret](English-Quest-backend-lokal-manual.zip)
- [Bundle Git pemulihan](English-Quest-c8301ad.bundle) · [alternatif patch](English-Quest-502ec4c-ke-c8301ad.patch)
- [Checksum bundle/patch/backend ZIP](SHA256SUMS.txt)

**Unduh APK dan bundle untuk menyimpan hasil secara mandiri.** Direktori build/cache tidak persisten;
berkas serah-terima disalin ke workspace, tetapi penyimpanan snapshot workspace bukan pengganti
salinan milik pemilik. Tidak menghapus atau mengganti APK lama untuk mengurangi ukuran workspace.

## A. Source dan perubahan yang benar-benar tersedia

### Pemeriksaan awal, bukan asumsi dari laporan terdahulu

1. `/home/user/english-quest` ada tetapi tanpa `.git`.
2. Branch remote audit masih `502ec4c59d1d59cb19c29b8ff528e07412f53252`. `main` masih
   `d05e4e6783131ea96734ce60889f05c1aa852305`, tidak diubah.
3. Bundle `9c105ee` diperiksa terhadap basis 502ec4c, lalu dipulihkan di checkout audit terpisah.
   Rantai commit nyata: **502ec4c → 6064027 → 9c105ee**. Jadi source manual yang tersedia lebih baru
   daripada commit acuan remote 502ec4c.
4. Backend/UI web manual cocok dengan 9c105ee, tetapi **tujuh file Android berbeda dan dua overlay
   debug hilang**. Termasuk aset manual, bridge API, build.gradle dan konfigurasi debug. Delapan
   berkas bukti uji historis juga tidak tersedia di loose workspace.
5. File yang berbeda dicadangkan ke `sebelum-pemulihan/`, lalu salinan Android dipulihkan dari commit
   yang tervalidasi. Tidak menulis ulang implementasi manual yang sudah benar.

Setelah pemulihan, **123 berkas baseline 9c105ee identik byte-for-byte**. Perbaikan register/login,
manual payment, aktivasi dan materi belajar dipertahankan. Tidak ada file source lama atau database
pengguna yang dihapus. Bukti awal: `INSPEKSI-AWAL.txt` dan `evidence/debug-manual/inspeksi-awal.txt`.

### Alur manual yang dipertahankan dan diuji ulang

- Harga Rp5.000, sekali bayar, permanen, tanpa langganan; demo tetap 5 soal Easy.
- Nomor/nama DANA berasal dari konfigurasi. Kosong/tidak valid berarti pembayaran belum tersedia.
- “Saya Sudah Membayar” hanya mencatat pending dengan order ID/akun, tidak memberi token/Premium.
- Admin harus memeriksa transaksi DANA masuk yang sebenarnya, bukan hanya screenshot, kemudian
  memverifikasi dan secara terpisah menerbitkan token.
- Semua persetujuan/penolakan/penerbitan memeriksa role admin di backend. Admin tidak boleh
  memverifikasi pesanan miliknya sendiri; akun lain tidak dapat membaca/mengaktifkan pesanan itu.
- Nominal 5000 wajib; referensi transaksi unik berupa HMAC; audit dan transisi atomik.
- Satu order hanya menghasilkan satu token. Retry dan penerbitan bersamaan tidak menambah kode.
- Token hanya untuk akun pemilik pesanan. Klaim akun lain ditolak; retry pemilik bersifat idempoten,
  bukan aktivasi akun kedua atau tambahan entitlement.
- Tidak ada plaintext token dalam DB; aktivasi sah tidak memiliki expiry dan tersimpan di server
  setelah logout/login/restart/backup-restore. Saat server tidak dapat diverifikasi, akses tetap
  fail-closed; “permanen” tidak berarti memercayai flag lokal saat offline.

Migrasi aditif `manual_dana_v1`, tabel pesanan/audit/migrasi dan indeks tetap utuh. Tidak menjalankan
migrasi pada database pelanggan/produksi. Semua pengujian data menggunakan fixture sintetis terisolasi.

### Tambahan baru pada sesi ini

- `tools/build-apk-debug-manual.sh`: memeriksa parity/bridge sebelum build, menjalankan suite tes,
  membangun hanya debug, lalu memverifikasi APK. Menolak otomatis membuat debug key jika belum ada.
- `tools/verifikasi-apk-debug-manual.py`: membaca APK nyata untuk memeriksa identitas, signature,
  17 aset, DEX bridge/origin, konfigurasi loopback, model Vosk, dan pola berkas/kredensial terlarang.
- `tools/backend-lokal-manual.py`: launcher HP/komputer lokal dengan DB dan pepper uji yang stabil;
  hanya loopback, penerima DANA kosong, tidak mewarisi konfigurasi produksi.
- `tests/test_local_manual_launcher.py`: empat tes baru untuk persistensi pepper, izin berkas privat,
  penolakan DB tanpa pepper, dan isolasi konfigurasi.
- `PANDUAN-APK-DEBUG-MANUAL.md` dan bukti pemeriksaan/build di `evidence/debug-manual/`.

Source runtime aplikasi tetap identik dengan 9c105ee; commit baru hanya menambah helper, tes,
panduan dan bukti. Final **142 berkas tracked** di source aktif cocok dengan commit final.

## B. Pengujian lokal yang benar-benar dijalankan

| Pemeriksaan | Hasil sesi ini |
|---|---|
| Seluruh unittest Python, run akhir | **106 lulus, 0 gagal, 0 skipped**, 28,566 detik |
| Komposisi Python | 74 tes baseline + 28 pembayaran manual + 4 launcher lokal |
| Node registrasi/login | 13 kelompok lulus, termasuk backend nyata |
| Node kegagalan koneksi | 8 kelompok lulus, termasuk timeout/401/500/fail-closed |
| Node gates | 11 kelompok lulus + 43 renderer smoke-tested |
| Node manual buyer/admin | 10 kelompok lulus |
| Total kelompok Node | **42**, tidak menjumlahkan ulang renderer atau asset pairs sebagai tes terpisah |
| Aset root ↔ Android source ↔ APK | **17 berkas identik**; cache v20 |
| Launcher backend lokal | 8 pemeriksaan smoke lulus, tanpa membuat akun/pesanan |
| Paket ZIP setelah ekstraksi | 9 berkas cocok source; 4 endpoint smoke lulus |
| Simulator legacy otomatis | 18 langkah lulus, hanya fixture lokal untuk regresi, bukan alur produksi |
| Sintaks | Python compile, Node app/client/admin, shell syntax lulus |
| Git / pemulihan | diff check, fsck dan bundle verify lulus |

Run awal sebelum helper ditambah adalah 102 tes; run akhir 106 mencakup tes-tes itu kembali.
**Tidak mengklaim 208 tes unik.** Seluruh file tes lama tetap sama; tidak mengubah assertion lama
agar hasil lulus. `cryptography` dipasang lokal untuk tes adapter lama agar tidak skipped.

28 tes manual mencakup pending tanpa Premium, admin tidak sah, verifikasi nominal/receipt,
pending/rejected tidak bisa menerbitkan, enam penerbitan bersamaan hanya satu kode, ownership,
penolakan reuse akun lain, aktivasi permanen, logout/login/restart, penyimpanan tanpa plaintext,
audit, rollback saat error, migrasi nondestruktif, dan backup/restore.

Ada tes **TLS lokal nyata** di suite: daftar → pending → verifikasi admin → issue → aktivasi →
logout/login. Bukan TLS verification dimatikan dan bukan pengujian internet/HP. Data “dana masuk”
pada tes hanyalah fixture; tidak ada koneksi atau transaksi DANA, dan tidak dianggap bukti uang nyata.

Bukti utama: `evidence/debug-manual/final-pipeline.txt`. File `python-tests.txt` merekam run awal 102,
sehingga untuk jumlah akhir gunakan `final-pipeline.txt`.

## C. Pengujian gagal, peringatan, dan batas bukti

- **Tidak ada kegagalan dalam suite otomatis akhir atau build debug.**
- Pemeriksaan awal “signer sama dengan APK historis root” **gagal**. Ini temuan nyata yang tetap
  berlaku: signer berbeda. Verifikasi ulang menunjukkan signer baru sama dengan APK uji lokal
  pendaftaran terdahulu, bukan root APK. Jangan mengklaim update di atas semua APK lama akan berhasil.
- Smoke check ZIP ad-hoc awal gagal karena mencocokkan spasi JSON. Pemeriksaan diganti dengan parsing
  JSON, kemudian keempat endpoint diuji ulang dan lulus. Tidak mengubah aplikasi untuk mengakali tes.
- Gradle memperingatkan penggunaan API Android deprecated dan library native `libjnidispatch.so` /
  `libvosk.so` tidak dapat di-strip; keduanya tetap dipaketkan. Build berhasil, fitur tidak dihapus.
- Tidak ada uji instalasi/emulator/HP, mikrofon, ASR, TTS atau perilaku WebView fisik. Verifikasi APK
  statis/Node bukan bukti perangkat sudah menjalankannya.

## D. APK debug yang benar-benar dibangun

| Atribut | Hasil |
|---|---|
| Status | **BUILD SUCCESSFUL** |
| Build pertama | 1 menit 22 detik; **35 tugas executed**, bukan memakai APK lama |
| Pipeline verifikasi ulang | Berhasil; 11 detik Gradle, 1 tugas executed / 34 up-to-date |
| Hasil asli Gradle | `/home/user/english-quest/english-quest-android/app/build/outputs/apk/debug/app-debug.apk` |
| Salinan unduhan | `/home/user/artefak-apk/English-Quest-1.7.1-dana-manual-localtest-debug.apk` |
| Ukuran | **84.922.352 byte / 80,99 MiB** |
| applicationId debug | **`com.englishquest.app.debug`**, suffix debug yang sudah ada |
| applicationId dasar | `com.englishquest.app`, tidak diubah |
| versionName / versionCode | **`1.7.1-debug` / `13`**, tidak dinaikkan |
| Android | minSdk 23 / targetSdk 35 / compileSdk 35 |
| Origin API | **`http://127.0.0.1:8088`**, khusus backend lokal pada HP atau adb reverse |
| HTTP dev | Aktif untuk debug; config jaringan membatasi pengecualian ke loopback |
| Toolchain | Temurin JDK 17.0.20.1, Gradle 8.9, AGP 8.7.3, SDK 35 |
| Tanda tangan | Valid v1/v2; kunci debug yang sudah ada, bukan kunci produksi baru |

**SHA-256 APK baru:**

```text
38cd8f9560937fde17404eb8ef9ff382a087a4e652df9dfb2ec80fe7d4d4923e
```

Signer SHA-256:

```text
7659afc54a848321ff9a88c1604254af2d768c504e4adb6fdd92f490d7c950a3
```

APK historis root **tidak ditimpa**, SHA-nya tetap
`05e066414f831de225087d47bf00f3892810cc70b3343c5a228cfeda914bbd86`.
APK rilis tidak dibangun/diganti. Tidak ada perubahan identitas atau versionCode untuk menghindari
konflik tanda tangan.

Isi APK dibandingkan langsung: app.js memuat UI manual/Saya Sudah Membayar/harga; client memakai
endpoint manual; DEX memuat bridge API dan origin loopback; 17 aset cocok; arsip Vosk cocok pinned
SHA-256. Tidak ada DB/keystore/private key/berkas .env, atau pola PAT/token Premium plaintext yang
terdeteksi. Pemindaian pola bukan audit rahasia menyeluruh, tetapi tidak ada rahasia produksi yang
memang dimasukkan selama pekerjaan ini.

### Langkah uji HP

Panduan lengkap ada di **PANDUAN-HP.md**. Ringkasnya:
1. Unduh APK/checksum; periksa SHA; pasang pada lingkungan uji dengan signer yang sesuai.
2. Jika bentrok signer, berhenti. Jangan uninstall/data-clear tanpa backup dan keputusan pemilik.
3. Tanpa backend, periksa demo lokal/pesan gagal koneksi; jangan mengharapkan login/Premium berhasil.
4. Pada HP yang sama, ekstrak backend ZIP ke home Termux; jalankan
   `python3 tools/backend-lokal-manual.py serve`.
5. Buka `/api/health`, lalu coba register/login/logout/restart lewat APK. DB dan pepper uji disimpan.
6. Penerima kosong harus memberi “pembayaran belum tersedia”. Admin dapat dibuat lewat terminal
   oleh pemilik untuk menguji otorisasi panel, bukan dengan PIN/akun bawaan APK.

Launcher ini sengaja tidak mengaktifkan rekening DANA. Tidak perlu membayar untuk menguji instalasi,
koneksi, akun, keadaan konfigurasi kosong dan otorisasi. Pengujian transaksi riil memerlukan tahap
terpisah yang belum diizinkan/dijalankan.

## E. Git, penyimpanan dan pekerjaan tertunda

**Commit akhir lokal:** `c8301ad6453fd45ea79d8c1466b674b7473c52bb`  
**Branch:** `audit-baseline-1.7.1`  
**Pesan:** `Verify manual-payment debug APK and add safe phone-local test tools`

Commit menambah 19 berkas (helper, tes, panduan dan bukti). Tidak memasukkan APK baru, DB atau kunci ke
Git. Checkout akhir bersih. Direktori checkout `.cache/eq-build-audit` tidak diandalkan untuk persistensi;
source aktif dan artefak bundle berada di workspace, dan salinan unduhan pemilik tetap disarankan.

Bundle **118.613 byte**, tervalidasi, mencakup tiga commit lokal 6064027 + 9c105ee + c8301ad dengan
prasyarat commit remote 502ec4c. Patch alternatif **450.631 byte** memiliki basis yang sama. Backend ZIP
**48.016 byte** dapat digunakan untuk tes HP tanpa menunggu push atau mengunduh repo/APK historis besar.
Gunakan bundle ATAU patch, bukan keduanya berurutan.

Untuk clone bersih dengan basis 502ec4c:

```sh
git switch audit-baseline-1.7.1
git bundle verify /path/ke/English-Quest-c8301ad.bundle
git fetch /path/ke/English-Quest-c8301ad.bundle refs/heads/audit-baseline-1.7.1
git merge --ff-only FETCH_HEAD
```

Sesuaikan path, hentikan jika ada perubahan lokal/benturan; jangan force/reset/main. Setelah autentikasi
browser langsung pada perangkat pemilik tersedia, push audit dapat dilanjutkan sesuai izin terdahulu.

**Push belum dilakukan.** Remote audit diperiksa ulang dan masih 502ec4c. Tidak mencoba memakai PAT
terpapar atau meminta credential melalui chat. `main` tetap d05e4e6.

Masih tertunda: uji HP nyata, konfigurasi penerima sah, hosting/HTTPS/persistent DB publik, kanal
penyerahan kode/refund, serta build produksi untuk origin nyata. Tidak ada deployment atau transaksi
nyata. Premium lokal teruji tidak sama dengan pembayaran/pendaftaran publik sudah siap.

## F. Tindakan atau persetujuan pemilik

- Unduh APK, checksum dan bundle sekarang untuk salinan mandiri.
- Jalankan checklist HP dan laporkan hasil/pesan error tanpa password/token.
- Jika terpasang APK dengan signer berbeda, tentukan pilihan instalasi/backup; data tidak dihapus
  otomatis. Jangan mengirim signing key ke chat.
- Selesaikan autentikasi push langsung melalui browser/perangkat sendiri jika ingin memperbarui GitHub.
  Cabut PAT yang pernah terpapar; tidak perlu mengirim PAT baru.
- Sebelum penggunaan nyata: konfirmasi nomor/nama DANA, pilihan hosting anggaran nol yang memenuhi
  persistensi, jalur admin HTTPS, dan izin deployment. Belum memilih/membeli/mengaktifkan layanan.
- Ingat token manual hanya tampil sekali kepada admin; kode yang hilang tidak dapat diambil ulang
  dari hash atau diterbitkan ulang otomatis. Tetapkan prosedur dukungan sebelum melayani pembeli.

Tidak ada pekerjaan lokal pada enam tahap yang ditinggalkan hanya karena push/hosting/nomor DANA:
source dipulihkan, suite dijalankan, APK dibangun dan diperiksa, backend uji dikemas, serta perubahan
aman tersedia dalam bundle/patch. Batas berikutnya adalah penggunaan perangkat/layanan milik pemilik,
bukan klaim bahwa layanan produksi sudah selesai.
